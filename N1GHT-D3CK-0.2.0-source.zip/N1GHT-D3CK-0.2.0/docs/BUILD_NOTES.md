# Build notes

Portable source is configured for Android Gradle Plugin 8.10.1, Gradle 8.11.1, Java 17 bytecode, compile/target SDK 36, and minimum SDK 26.

The checked-in repository configuration uses Google Maven, Maven Central, and Gradle Plugin Portal only. Machine-specific SDK paths, caches, credentials, signing secrets, and downloaded toolchains are excluded.

The debug build uses Android's standard debug signing configuration. Production signing remains outside the 0.2.0 testing build.

## Gradle wrapper boundary

The wrapper scripts and `gradle-wrapper.properties` are present. The wrapper JAR is intentionally restored through the official `gradle wrapper` task inside GitHub Actions when it is absent from the portable archive.

## Build command

```bash
./gradlew --no-daemon assembleDebug --stacktrace
```

## GitHub Actions artifact

The included workflow uploads:

```text
N1GHT-D3CK-0.2.0-debug.apk
N1GHT-D3CK-0.2.0-checksums.txt
apksigner-verification.txt
zipalign-verification.txt
aapt2-badging.txt
```
