# Architecture

## Rules engine

`engine/` is pure Java and owns cards, deal generation, legal moves, invariant verification, undo snapshots, exact-deal restart, deterministic seeded shuffles, hints, win detection, and save-state encoding. It has no Android dependency.

## Native presentation

`NightDeckView` is a single native Android custom `View` that renders the complete experience with Canvas primitives. It now contains explicit presentation states for:

- Home
- Game board
- Statistics
- Settings
- How to Play
- About / gift dedication
- Victory
- Pause menu and confirmation overlays

Tap controls remain the primary interaction. The view calculates system-bar insets and responsive card geometry at runtime, so the board does not depend on one fixed phone resolution.

## Activity and system UI

`MainActivity` configures transparent system bars, keeps light icons, and delegates lifecycle persistence and back navigation to the custom view.

## Local persistence

`StatsStore` uses app-private `SharedPreferences` for game state, settings, and statistics. No cloud service, account, external storage, analytics SDK, network client, or Android permission is used.
