# Test scope

The JUnit suite covers:

- 52 unique cards and correct 1–7 initial tableau deal
- Initial face-up / face-down states
- Deterministic seeded shuffles
- Legal and illegal tableau placement
- King-only empty columns
- Ordered sequence validation
- Legal and illegal foundation progression
- Draw-one stock behavior and waste recycling order
- Illegal-move immutability
- Exact undo, restart, and save/restore
- Automatic card exposure after a legal move
- Win detection only with all 52 cards in foundations
- Repeated no-duplicate / no-missing-card checks

`tools/EngineSelfTest.java` provides a dependency-free executable subset for environments that cannot resolve JUnit or Android tooling.
