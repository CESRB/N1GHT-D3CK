package com.cesrblabs.nightdeck.engine;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class GameState {
    public final List<List<Card>> tableau = new ArrayList<>();
    public final List<List<Card>> foundations = new ArrayList<>();
    public final List<Card> stock = new ArrayList<>();
    public final List<Card> waste = new ArrayList<>();
    public long seed;
    public int moves;
    public long elapsedSeconds;
    public boolean wonRecorded;

    public GameState() {
        for (int i = 0; i < 7; i++) tableau.add(new ArrayList<>());
        for (int i = 0; i < 4; i++) foundations.add(new ArrayList<>());
    }

    public int cardCount() {
        int n = stock.size() + waste.size();
        for (List<Card> p : tableau) n += p.size();
        for (List<Card> p : foundations) n += p.size();
        return n;
    }

    public boolean hasExactly52UniqueCards() {
        Set<String> ids = new HashSet<>();
        for (Card c : allCards()) ids.add(c.id());
        return cardCount() == 52 && ids.size() == 52;
    }

    public List<Card> allCards() {
        List<Card> all = new ArrayList<>(52);
        all.addAll(stock); all.addAll(waste);
        for (List<Card> p : tableau) all.addAll(p);
        for (List<Card> p : foundations) all.addAll(p);
        return all;
    }
}
