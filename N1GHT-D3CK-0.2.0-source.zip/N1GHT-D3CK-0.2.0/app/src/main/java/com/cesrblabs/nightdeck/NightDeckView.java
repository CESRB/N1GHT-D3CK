package com.cesrblabs.nightdeck;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;

import com.cesrblabs.nightdeck.engine.Card;
import com.cesrblabs.nightdeck.engine.GameEngine;
import com.cesrblabs.nightdeck.engine.Suit;

import java.util.List;
import java.util.Locale;

public final class NightDeckView extends View {
    private enum Screen { HOME, GAME, STATS, SETTINGS, ABOUT, GUIDE, WIN }
    private enum ConfirmAction { NONE, NEW_GAME, RESTART }

    private static final int NIGHT = Color.rgb(8, 7, 12);
    private static final int NIGHT_2 = Color.rgb(15, 11, 21);
    private static final int PANEL = Color.rgb(25, 20, 32);
    private static final int PANEL_2 = Color.rgb(34, 27, 43);
    private static final int BORDER = Color.rgb(78, 61, 94);
    private static final int PURPLE = Color.rgb(117, 66, 154);
    private static final int PINK = Color.rgb(242, 75, 165);
    private static final int SOFT_PINK = Color.rgb(255, 171, 218);
    private static final int TEXT = Color.rgb(248, 243, 249);
    private static final int MUTED = Color.rgb(183, 169, 190);
    private static final int IVORY = Color.rgb(248, 245, 246);
    private static final int INK = Color.rgb(37, 31, 41);
    private static final int RED = Color.rgb(183, 39, 86);
    private static final int GREEN = Color.rgb(85, 207, 156);

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final StatsStore store;
    private final GameEngine engine;
    private final ToneGenerator tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 28);
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final RectF homeContinue = new RectF();
    private final RectF homeNew = new RectF();
    private final RectF homeStats = new RectF();
    private final RectF homeSettings = new RectF();
    private final RectF homeAbout = new RectF();

    private final RectF screenBack = new RectF();
    private final RectF topMenu = new RectF();
    private final RectF[] actionRects = new RectF[4];
    private final RectF stockRect = new RectF();
    private final RectF wasteRect = new RectF();
    private final RectF[] foundationRects = new RectF[4];
    private final RectF[] tableauRects = new RectF[7];

    private final RectF[] settingRows = new RectF[4];
    private final RectF settingsAbout = new RectF();
    private final RectF[] statCards = new RectF[4];

    private final RectF menuPanel = new RectF();
    private final RectF[] menuRows = new RectF[5];
    private final RectF confirmPanel = new RectF();
    private final RectF confirmCancel = new RectF();
    private final RectF confirmAccept = new RectF();
    private final RectF winHome = new RectF();
    private final RectF winNew = new RectF();

    private float density;
    private int viewWidth;
    private int viewHeight;
    private int topInset;
    private int bottomInset;
    private float safeTop;
    private float safeBottom;
    private float boardLeft;
    private float boardWidth;
    private float cardW;
    private float cardH;
    private float cardGap;
    private float pileY;
    private float tableauY;
    private float tableauBottom;
    private float bottomBarTop;

    private Screen screen = Screen.HOME;
    private Screen settingsOrigin = Screen.HOME;
    private Screen aboutOrigin = Screen.HOME;
    private ConfirmAction confirmAction = ConfirmAction.NONE;
    private boolean gameMenuOpen;
    private boolean hasSavedGame;
    private boolean gameInProgress;
    private String message = "Choose a card or draw from the deck";
    private long lastTapTime;
    private String lastTapKey = "";

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (screen == Screen.GAME && gameInProgress && !engine.isWon()
                    && !gameMenuOpen && confirmAction == ConfirmAction.NONE) {
                engine.state().elapsedSeconds++;
            }
            invalidate();
            handler.postDelayed(this, 1000);
        }
    };

    public NightDeckView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        store = new StatsStore(context);
        engine = new GameEngine(System.currentTimeMillis());
        hasSavedGame = store.loadGame(engine);
        gameInProgress = hasSavedGame;

        setBackgroundColor(NIGHT);
        setFocusable(true);
        setClickable(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        stroke.setStyle(Paint.Style.STROKE);

        setOnApplyWindowInsetsListener((view, insets) -> {
            topInset = insets.getSystemWindowInsetTop();
            bottomInset = insets.getSystemWindowInsetBottom();
            computeLayout();
            invalidate();
            return insets;
        });
        requestApplyInsets();
        handler.postDelayed(ticker, 1000);
    }

    public void persist() {
        if (gameInProgress) {
            store.saveGame(engine);
            hasSavedGame = true;
        }
    }

    public boolean handleBackPressed() {
        if (confirmAction != ConfirmAction.NONE) {
            confirmAction = ConfirmAction.NONE;
            invalidate();
            return true;
        }
        if (gameMenuOpen) {
            gameMenuOpen = false;
            invalidate();
            return true;
        }
        switch (screen) {
            case GAME:
                goHome();
                return true;
            case SETTINGS:
                screen = settingsOrigin;
                invalidate();
                return true;
            case ABOUT:
                screen = aboutOrigin;
                invalidate();
                return true;
            case STATS:
            case GUIDE:
            case WIN:
                screen = Screen.HOME;
                invalidate();
                return true;
            case HOME:
            default:
                return false;
        }
    }

    @Override protected void onDetachedFromWindow() {
        handler.removeCallbacks(ticker);
        tones.release();
        persist();
        super.onDetachedFromWindow();
    }

    private float dp(float value) { return value * density; }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        viewWidth = w;
        viewHeight = h;
        computeLayout();
    }

    private void computeLayout() {
        if (viewWidth <= 0 || viewHeight <= 0) return;
        safeTop = topInset + dp(8);
        safeBottom = viewHeight - bottomInset - dp(8);
        float usable = Math.max(dp(520), safeBottom - safeTop);

        float buttonWidth = Math.min(viewWidth - dp(40), dp(380));
        float buttonLeft = (viewWidth - buttonWidth) / 2f;
        float buttonH = dp(56);
        float homeButtonsTop = safeTop + usable * 0.58f;
        float needed = buttonH * 2 + dp(72) + dp(42);
        if (homeButtonsTop + needed > safeBottom) homeButtonsTop = safeBottom - needed;
        homeContinue.set(buttonLeft, homeButtonsTop, buttonLeft + buttonWidth, homeButtonsTop + buttonH);
        homeNew.set(buttonLeft, homeContinue.bottom + dp(11), buttonLeft + buttonWidth, homeContinue.bottom + dp(11) + buttonH);
        float halfGap = dp(10);
        float halfW = (buttonWidth - halfGap) / 2f;
        homeStats.set(buttonLeft, homeNew.bottom + dp(12), buttonLeft + halfW, homeNew.bottom + dp(12) + dp(52));
        homeSettings.set(homeStats.right + halfGap, homeStats.top, buttonLeft + buttonWidth, homeStats.bottom);
        homeAbout.set(buttonLeft + buttonWidth * .22f, homeStats.bottom + dp(8), buttonLeft + buttonWidth * .78f, homeStats.bottom + dp(46));

        screenBack.set(dp(12), safeTop + dp(4), dp(52), safeTop + dp(44));
        topMenu.set(viewWidth - dp(52), safeTop + dp(4), viewWidth - dp(12), safeTop + dp(44));

        boardWidth = Math.min(viewWidth - dp(16), dp(520));
        boardLeft = (viewWidth - boardWidth) / 2f;
        cardGap = Math.max(dp(3), Math.min(dp(6), boardWidth * .012f));
        cardW = (boardWidth - cardGap * 6f) / 7f;
        cardH = cardW * 1.46f;
        pileY = safeTop + dp(88);
        tableauY = pileY + cardH + dp(17);
        bottomBarTop = safeBottom - dp(58);
        tableauBottom = bottomBarTop - dp(8);

        for (int i = 0; i < 7; i++) {
            float left = boardLeft + i * (cardW + cardGap);
            tableauRects[i].set(left, tableauY, left + cardW, tableauBottom);
        }
        stockRect.set(tableauRects[0].left, pileY, tableauRects[0].right, pileY + cardH);
        wasteRect.set(tableauRects[1].left, pileY, tableauRects[1].right, pileY + cardH);
        for (int i = 0; i < 4; i++) {
            foundationRects[i].set(tableauRects[3 + i].left, pileY, tableauRects[3 + i].right, pileY + cardH);
        }

        float actionGap = dp(7);
        float actionSide = dp(10);
        float actionW = (viewWidth - actionSide * 2 - actionGap * 3) / 4f;
        for (int i = 0; i < 4; i++) {
            float left = actionSide + i * (actionW + actionGap);
            actionRects[i].set(left, bottomBarTop, left + actionW, safeBottom);
        }

        float contentTop = safeTop + dp(74);
        float panelWidth = Math.min(viewWidth - dp(32), dp(430));
        float panelLeft = (viewWidth - panelWidth) / 2f;
        for (int i = 0; i < 4; i++) {
            float y = contentTop + i * dp(69);
            settingRows[i].set(panelLeft, y, panelLeft + panelWidth, y + dp(58));
        }
        settingsAbout.set(panelLeft, settingRows[3].bottom + dp(18), panelLeft + panelWidth, settingRows[3].bottom + dp(72));

        float statGap = dp(10);
        float statW = (panelWidth - statGap) / 2f;
        for (int i = 0; i < 4; i++) {
            int row = i / 2;
            int col = i % 2;
            float left = panelLeft + col * (statW + statGap);
            float top = contentTop + row * dp(108);
            statCards[i].set(left, top, left + statW, top + dp(96));
        }

        float menuW = Math.min(viewWidth - dp(40), dp(340));
        float menuH = dp(344);
        menuPanel.set((viewWidth - menuW) / 2f, (viewHeight - menuH) / 2f,
                (viewWidth + menuW) / 2f, (viewHeight + menuH) / 2f);
        for (int i = 0; i < 5; i++) {
            float y = menuPanel.top + dp(58) + i * dp(52);
            menuRows[i].set(menuPanel.left + dp(18), y, menuPanel.right - dp(18), y + dp(44));
        }

        float confirmW = Math.min(viewWidth - dp(42), dp(360));
        float confirmH = dp(232);
        confirmPanel.set((viewWidth - confirmW) / 2f, (viewHeight - confirmH) / 2f,
                (viewWidth + confirmW) / 2f, (viewHeight + confirmH) / 2f);
        float confirmButtonW = (confirmW - dp(54)) / 2f;
        confirmCancel.set(confirmPanel.left + dp(18), confirmPanel.bottom - dp(62),
                confirmPanel.left + dp(18) + confirmButtonW, confirmPanel.bottom - dp(18));
        confirmAccept.set(confirmCancel.right + dp(18), confirmCancel.top,
                confirmPanel.right - dp(18), confirmCancel.bottom);

        float winButtonW = Math.min(viewWidth - dp(46), dp(360));
        float winLeft = (viewWidth - winButtonW) / 2f;
        winNew.set(winLeft, safeBottom - dp(136), winLeft + winButtonW, safeBottom - dp(78));
        winHome.set(winLeft, safeBottom - dp(66), winLeft + winButtonW, safeBottom - dp(10));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        switch (screen) {
            case HOME: drawHome(canvas); break;
            case GAME: drawGame(canvas); break;
            case STATS: drawStats(canvas); break;
            case SETTINGS: drawSettings(canvas); break;
            case ABOUT: drawAbout(canvas); break;
            case GUIDE: drawGuide(canvas); break;
            case WIN: drawWin(canvas); break;
        }
        if (gameMenuOpen) drawGameMenu(canvas);
        if (confirmAction != ConfirmAction.NONE) drawConfirmation(canvas);
    }

    private void drawAmbientBackground(Canvas c, boolean hero) {
        c.drawColor(NIGHT);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(viewWidth * .72f, safeTop + dp(180),
                Math.max(viewWidth, viewHeight) * .66f,
                new int[]{Color.argb(hero ? 90 : 52, 119, 45, 142), Color.argb(20, 68, 34, 90), NIGHT},
                new float[]{0f, .44f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, viewWidth, viewHeight, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(.7f));
        paint.setColor(Color.argb(hero ? 24 : 17, 178, 120, 205));
        float grid = dp(42);
        for (float x = -grid; x < viewWidth + grid; x += grid) c.drawLine(x, safeTop, x, safeBottom, paint);
        for (float y = safeTop; y < safeBottom; y += grid) c.drawLine(0, y, viewWidth, y, paint);
        paint.setStyle(Paint.Style.FILL);

        long t = SystemClock.uptimeMillis();
        float drift = store.reducedMotion() ? 0 : (float) Math.sin(t / 1700.0) * dp(8);
        paint.setColor(Color.argb(38, 242, 75, 165));
        c.drawRect(0, safeTop + dp(118) + drift, dp(48), safeTop + dp(120) + drift, paint);
        c.drawRect(viewWidth - dp(62), safeBottom - dp(142) - drift, viewWidth, safeBottom - dp(140) - drift, paint);
        paint.setColor(Color.argb(24, 122, 76, 164));
        c.drawRect(viewWidth * .30f, safeTop + dp(12), viewWidth * .64f, safeTop + dp(13), paint);
    }

    private void drawHome(Canvas c) {
        drawAmbientBackground(c, true);
        if (!store.reducedMotion()) postInvalidateDelayed(48);

        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(Color.argb(70, 242, 75, 165));
        paint.setTextSize(dp(38));
        c.drawText("N1GHT D3CK", viewWidth / 2f + dp(2), safeTop + dp(72), paint);
        paint.setColor(TEXT);
        c.drawText("N1GHT D3CK", viewWidth / 2f, safeTop + dp(69), paint);
        paint.setTextSize(dp(11));
        paint.setLetterSpacing(.16f);
        paint.setColor(SOFT_PINK);
        c.drawText("SOLITAIRE AFTER DARK", viewWidth / 2f, safeTop + dp(91), paint);
        paint.setLetterSpacing(0);

        RectF giftChip = new RectF(viewWidth / 2f - dp(60), safeTop + dp(106),
                viewWidth / 2f + dp(60), safeTop + dp(135));
        drawChip(c, giftChip, "MADE FOR ECHO", true);

        float heroY = safeTop + Math.min(dp(255), (safeBottom - safeTop) * .34f);
        float heroW = Math.min(dp(108), viewWidth * .25f);
        float heroH = heroW * 1.46f;
        drawHeroCard(c, new RectF(viewWidth / 2f - heroW * 1.28f, heroY - heroH / 2f,
                viewWidth / 2f - heroW * .28f, heroY + heroH / 2f), -12, null, true);
        drawHeroCard(c, new RectF(viewWidth / 2f + heroW * .28f, heroY - heroH / 2f,
                viewWidth / 2f + heroW * 1.28f, heroY + heroH / 2f), 12,
                new Card(Suit.SPADES, 1, true), false);
        drawHeroCard(c, new RectF(viewWidth / 2f - heroW / 2f, heroY - heroH * .57f,
                viewWidth / 2f + heroW / 2f, heroY + heroH * .43f), 0,
                new Card(Suit.HEARTS, 12, true), false);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(12));
        paint.setColor(MUTED);
        c.drawText("A quiet deck for late nights.", viewWidth / 2f, heroY + heroH * .72f, paint);

        if (hasSavedGame) {
            drawHomeButton(c, homeContinue, "CONTINUE GAME",
                    engine.state().moves + " moves  •  " + formatTime(engine.state().elapsedSeconds), true);
            drawHomeButton(c, homeNew, "NEW DEAL", "Shuffle a fresh deck", false);
        } else {
            drawHomeButton(c, homeContinue, "NEW GAME", "Shuffle your first deck", true);
            drawHomeButton(c, homeNew, "HOW TO PLAY", "A quick guide to the controls", false);
        }
        drawCompactButton(c, homeStats, "STATISTICS", "◇");
        drawCompactButton(c, homeSettings, "SETTINGS", "⚙");

        paint.setColor(MUTED);
        paint.setTextSize(dp(11));
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        c.drawText("ABOUT THIS GIFT", homeAbout.centerX(), homeAbout.centerY() + dp(4), paint);
        paint.setTextSize(dp(9));
        paint.setColor(Color.argb(150, 195, 178, 201));
        c.drawText("CESRB LABS  •  OFFLINE  •  NO ADS", viewWidth / 2f, safeBottom - dp(3), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawHeroCard(Canvas c, RectF r, float rotation, Card card, boolean back) {
        c.save();
        c.rotate(rotation, r.centerX(), r.centerY());
        if (back) drawCardBack(c, r, false);
        else drawFaceCard(c, card, r, false);
        c.restore();
    }

    private void drawHomeButton(Canvas c, RectF r, String title, String subtitle, boolean primary) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                primary ? new int[]{Color.rgb(202, 47, 139), Color.rgb(116, 49, 145)}
                        : new int[]{PANEL_2, PANEL}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, dp(15), dp(15), paint);
        paint.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(primary ? Color.argb(170, 255, 181, 224) : BORDER);
        c.drawRoundRect(r, dp(15), dp(15), stroke);

        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setColor(TEXT);
        paint.setTextSize(dp(14));
        c.drawText(title, r.left + dp(18), r.top + dp(24), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(10));
        paint.setColor(primary ? Color.argb(220, 255, 239, 248) : MUTED);
        c.drawText(subtitle, r.left + dp(18), r.top + dp(42), paint);
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setTextSize(dp(21));
        paint.setColor(primary ? TEXT : SOFT_PINK);
        c.drawText("›", r.right - dp(18), r.centerY() + dp(7), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawCompactButton(Canvas c, RectF r, String label, String icon) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(PANEL);
        c.drawRoundRect(r, dp(13), dp(13), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(BORDER);
        c.drawRoundRect(r, dp(13), dp(13), stroke);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setColor(SOFT_PINK);
        paint.setTextSize(dp(15));
        c.drawText(icon, r.left + dp(14), r.centerY() + dp(5), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(10));
        paint.setColor(TEXT);
        c.drawText(label, r.left + dp(39), r.centerY() + dp(4), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawGame(Canvas c) {
        drawAmbientBackground(c, false);
        drawGameHeader(c);
        drawPiles(c);
        drawTableau(c);
        drawActionBar(c);
    }

    private void drawGameHeader(Canvas c) {
        drawRoundIconButton(c, screenBack, "‹", false);
        drawRoundIconButton(c, topMenu, "⋯", false);

        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setColor(TEXT);
        paint.setTextSize(dp(16));
        paint.setTextAlign(Paint.Align.LEFT);
        c.drawText("N1GHT D3CK", dp(60), safeTop + dp(22), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(9));
        paint.setColor(SOFT_PINK);
        c.drawText("FOR ECHO", dp(60), safeTop + dp(38), paint);

        RectF moves = new RectF(viewWidth - dp(184), safeTop + dp(6), viewWidth - dp(132), safeTop + dp(42));
        RectF timer = new RectF(viewWidth - dp(126), safeTop + dp(6), viewWidth - dp(58), safeTop + dp(42));
        drawMetricPill(c, moves, Integer.toString(engine.state().moves), "MOVES");
        drawMetricPill(c, timer, formatTime(engine.state().elapsedSeconds), "TIME");

        RectF status = new RectF(dp(12), safeTop + dp(52), viewWidth - dp(12), safeTop + dp(80));
        paint.setColor(Color.argb(150, 25, 20, 32));
        c.drawRoundRect(status, dp(12), dp(12), paint);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(dp(10));
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setColor(MUTED);
        c.drawText(ellipsize(message, status.width() - dp(24)), status.centerX(), status.centerY() + dp(4), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawMetricPill(Canvas c, RectF r, String value, String label) {
        paint.setColor(Color.argb(180, 27, 21, 34));
        c.drawRoundRect(r, dp(10), dp(10), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(.8f));
        stroke.setColor(Color.argb(130, 94, 68, 108));
        c.drawRoundRect(r, dp(10), dp(10), stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(value.contains(":") ? dp(9) : dp(12));
        paint.setColor(TEXT);
        c.drawText(value, r.centerX(), r.top + dp(16), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(6.5f));
        paint.setColor(MUTED);
        c.drawText(label, r.centerX(), r.bottom - dp(6), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawPiles(Canvas c) {
        if (engine.state().stock.isEmpty()) drawEmptySlot(c, stockRect, "↻");
        else drawCardBack(c, stockRect, false);

        if (engine.state().waste.isEmpty()) drawEmptySlot(c, wasteRect, "W");
        else drawFaceCard(c, engine.state().waste.get(engine.state().waste.size() - 1), wasteRect,
                selected(GameEngine.SourceType.WASTE, 0, engine.state().waste.size() - 1));

        for (int i = 0; i < 4; i++) {
            List<Card> f = engine.state().foundations.get(i);
            if (f.isEmpty()) drawEmptySlot(c, foundationRects[i], Suit.values()[i].symbol);
            else drawFaceCard(c, f.get(f.size() - 1), foundationRects[i],
                    selected(GameEngine.SourceType.FOUNDATION, i, f.size() - 1));
        }

        paint.setColor(Color.argb(55, 242, 75, 165));
        c.drawRoundRect(new RectF(tableauRects[2].centerX() - dp(1), pileY + dp(9),
                tableauRects[2].centerX() + dp(1), pileY + cardH - dp(9)), dp(1), dp(1), paint);
    }

    private void drawTableau(Canvas c) {
        for (int col = 0; col < 7; col++) {
            List<Card> pile = engine.state().tableau.get(col);
            if (pile.isEmpty()) {
                drawEmptySlot(c, new RectF(tableauRects[col].left, tableauY,
                        tableauRects[col].right, tableauY + cardH), "K");
                continue;
            }
            float scale = columnScale(pile);
            float y = tableauY;
            for (int i = 0; i < pile.size(); i++) {
                Card card = pile.get(i);
                RectF r = new RectF(tableauRects[col].left, y, tableauRects[col].right, y + cardH);
                if (card.faceUp) drawFaceCard(c, card, r,
                        selected(GameEngine.SourceType.TABLEAU, col, i));
                else drawCardBack(c, r, false);
                if (i < pile.size() - 1) y += cardStep(card) * scale;
            }
        }
    }

    private float columnScale(List<Card> pile) {
        if (pile.size() <= 1) return 1f;
        float desired = 0;
        for (int i = 0; i < pile.size() - 1; i++) desired += cardStep(pile.get(i));
        float available = Math.max(dp(20), tableauBottom - tableauY - cardH);
        return desired <= available ? 1f : Math.max(.38f, available / desired);
    }

    private float cardStep(Card card) {
        return card.faceUp ? cardH * .29f : cardH * .135f;
    }

    private boolean selected(GameEngine.SourceType type, int pile, int index) {
        return engine.selection.type == type && engine.selection.pile == pile && engine.selection.index == index;
    }

    private void drawEmptySlot(Canvas c, RectF r, String text) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(90, 19, 14, 25));
        c.drawRoundRect(r, Math.max(dp(5), r.width() * .10f), Math.max(dp(5), r.width() * .10f), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(dp(.8f), r.width() * .015f));
        stroke.setColor(Color.argb(105, 132, 79, 150));
        stroke.setPathEffect(new DashPathEffect(new float[]{dp(4), dp(4)}, 0));
        c.drawRoundRect(r, Math.max(dp(5), r.width() * .10f), Math.max(dp(5), r.width() * .10f), stroke);
        stroke.setPathEffect(null);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(r.width() * .35f);
        paint.setColor(Color.argb(90, 255, 171, 218));
        c.drawText(text, r.centerX(), r.centerY() - (paint.ascent() + paint.descent()) / 2f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawFaceCard(Canvas c, Card card, RectF r, boolean isSelected) {
        float w = r.width();
        float h = r.height();
        float radius = Math.max(dp(5), w * .115f);

        paint.clearShadowLayer();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(105, 0, 0, 0));
        c.drawRoundRect(new RectF(r.left + w * .035f, r.top + w * .055f,
                r.right + w * .035f, r.bottom + w * .055f), radius, radius, paint);

        int cardTop = store.highContrast() ? Color.WHITE : IVORY;
        int cardBottom = store.highContrast() ? Color.rgb(248, 248, 248) : Color.rgb(232, 225, 234);
        paint.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                cardTop, cardBottom, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, radius, radius, paint);
        paint.setShader(null);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(isSelected ? Math.max(dp(2), w * .055f) : Math.max(dp(.7f), w * .018f));
        stroke.setColor(isSelected ? PINK : Color.rgb(112, 99, 116));
        if (isSelected) {
            stroke.setShadowLayer(w * .10f, 0, 0, Color.argb(180, 242, 75, 165));
        }
        c.drawRoundRect(r, radius, radius, stroke);
        stroke.clearShadowLayer();

        int ink = card.suit.red ? RED : INK;
        drawCardCorner(c, card, r.left + w * .11f, r.top + h * .13f, ink, false, w);
        c.save();
        c.rotate(180, r.centerX(), r.centerY());
        drawCardCorner(c, card, r.left + w * .11f, r.top + h * .13f, ink, false, w);
        c.restore();

        if (card.rank == 1) drawAceArt(c, card, r, ink);
        else if (card.rank >= 11) drawCourtArt(c, card, r, ink);
        else drawNumberPips(c, card, r, ink);

        if (isSelected) {
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(PINK);
            RectF tab = new RectF(r.centerX() - w * .16f, r.top - w * .045f,
                    r.centerX() + w * .16f, r.top + w * .035f);
            c.drawRoundRect(tab, w * .04f, w * .04f, paint);
        }
    }

    private void drawCardCorner(Canvas c, Card card, float x, float y, int ink, boolean centered, float width) {
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextAlign(centered ? Paint.Align.CENTER : Paint.Align.LEFT);
        paint.setColor(ink);
        paint.setTextSize(width * .25f);
        c.drawText(rankText(card.rank), x, y, paint);
        paint.setTextSize(width * .19f);
        c.drawText(card.suit.symbol, x, y + width * .22f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawAceArt(Canvas c, Card card, RectF r, int ink) {
        float w = r.width();
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(Color.argb(24, Color.red(ink), Color.green(ink), Color.blue(ink)));
        paint.setTextSize(w * .87f);
        c.drawText(card.suit.symbol, r.centerX(), r.centerY() + w * .28f, paint);
        paint.setColor(ink);
        paint.setTextSize(w * .53f);
        c.drawText(card.suit.symbol, r.centerX(), r.centerY() + w * .18f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawCourtArt(Canvas c, Card card, RectF r, int ink) {
        float w = r.width();
        float h = r.height();
        RectF portrait = new RectF(r.left + w * .23f, r.top + h * .23f,
                r.right - w * .23f, r.bottom - h * .23f);
        paint.setShader(new LinearGradient(portrait.left, portrait.top, portrait.right, portrait.bottom,
                new int[]{Color.rgb(47, 35, 57), card.suit.red ? Color.rgb(126, 35, 82) : Color.rgb(57, 47, 71), Color.rgb(27, 22, 34)},
                null, Shader.TileMode.CLAMP));
        c.drawRoundRect(portrait, w * .10f, w * .10f, paint);
        paint.setShader(null);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(w * .018f);
        stroke.setColor(Color.argb(120, 255, 200, 230));
        c.drawRoundRect(portrait, w * .10f, w * .10f, stroke);

        Path crown = new Path();
        crown.moveTo(portrait.left + portrait.width() * .18f, portrait.top + portrait.height() * .28f);
        crown.lineTo(portrait.left + portrait.width() * .34f, portrait.top + portrait.height() * .12f);
        crown.lineTo(portrait.centerX(), portrait.top + portrait.height() * .29f);
        crown.lineTo(portrait.left + portrait.width() * .66f, portrait.top + portrait.height() * .12f);
        crown.lineTo(portrait.right - portrait.width() * .18f, portrait.top + portrait.height() * .28f);
        crown.close();
        paint.setColor(SOFT_PINK);
        c.drawPath(crown, paint);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("serif", Typeface.BOLD));
        paint.setTextSize(w * .43f);
        paint.setColor(TEXT);
        c.drawText(rankText(card.rank), portrait.centerX(), portrait.centerY() + w * .15f, paint);
        paint.setTextSize(w * .20f);
        paint.setColor(Color.argb(220, Color.red(ink), Color.green(ink), Color.blue(ink)));
        c.drawText(card.suit.symbol, portrait.centerX(), portrait.bottom - portrait.height() * .13f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawNumberPips(Canvas c, Card card, RectF r, int ink) {
        float w = r.width();
        float h = r.height();
        float left = r.left + w * .34f;
        float center = r.centerX();
        float right = r.right - w * .34f;
        float top = r.top + h * .29f;
        float upper = r.top + h * .39f;
        float middle = r.centerY();
        float lower = r.bottom - h * .39f;
        float bottom = r.bottom - h * .29f;

        switch (card.rank) {
            case 2:
                pip(c, card, center, top, ink, false, w);
                pip(c, card, center, bottom, ink, true, w);
                break;
            case 3:
                pip(c, card, center, top, ink, false, w);
                pip(c, card, center, middle, ink, false, w);
                pip(c, card, center, bottom, ink, true, w);
                break;
            case 4:
                pipPair(c, card, left, right, top, ink, false, w);
                pipPair(c, card, left, right, bottom, ink, true, w);
                break;
            case 5:
                pipPair(c, card, left, right, top, ink, false, w);
                pip(c, card, center, middle, ink, false, w);
                pipPair(c, card, left, right, bottom, ink, true, w);
                break;
            case 6:
                pipPair(c, card, left, right, top, ink, false, w);
                pipPair(c, card, left, right, middle, ink, false, w);
                pipPair(c, card, left, right, bottom, ink, true, w);
                break;
            case 7:
                pipPair(c, card, left, right, top, ink, false, w);
                pip(c, card, center, upper, ink, false, w);
                pipPair(c, card, left, right, middle, ink, false, w);
                pipPair(c, card, left, right, bottom, ink, true, w);
                break;
            case 8:
                pipPair(c, card, left, right, top, ink, false, w);
                pip(c, card, center, upper, ink, false, w);
                pipPair(c, card, left, right, middle, ink, false, w);
                pip(c, card, center, lower, ink, true, w);
                pipPair(c, card, left, right, bottom, ink, true, w);
                break;
            case 9:
                pipPair(c, card, left, right, top, ink, false, w);
                pipPair(c, card, left, right, upper, ink, false, w);
                pip(c, card, center, middle, ink, false, w);
                pipPair(c, card, left, right, lower, ink, true, w);
                pipPair(c, card, left, right, bottom, ink, true, w);
                break;
            case 10:
                pipPair(c, card, left, right, top, ink, false, w);
                pip(c, card, center, upper, ink, false, w);
                pipPair(c, card, left, right, upper, ink, false, w);
                pipPair(c, card, left, right, lower, ink, true, w);
                pip(c, card, center, lower, ink, true, w);
                pipPair(c, card, left, right, bottom, ink, true, w);
                break;
            default:
                break;
        }
    }

    private void pipPair(Canvas c, Card card, float left, float right, float y, int ink, boolean flipped, float w) {
        pip(c, card, left, y, ink, flipped, w);
        pip(c, card, right, y, ink, flipped, w);
    }

    private void pip(Canvas c, Card card, float x, float y, int ink, boolean flipped, float w) {
        c.save();
        if (flipped) c.rotate(180, x, y);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(w * .20f);
        paint.setColor(ink);
        c.drawText(card.suit.symbol, x, y - (paint.ascent() + paint.descent()) / 2f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
        c.restore();
    }

    private void drawCardBack(Canvas c, RectF r, boolean isSelected) {
        float w = r.width();
        float h = r.height();
        float radius = Math.max(dp(5), w * .115f);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(105, 0, 0, 0));
        c.drawRoundRect(new RectF(r.left + w * .035f, r.top + w * .055f,
                r.right + w * .035f, r.bottom + w * .055f), radius, radius, paint);
        paint.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                new int[]{Color.rgb(34, 23, 43), Color.rgb(71, 30, 79), Color.rgb(20, 16, 27)},
                null, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, radius, radius, paint);
        paint.setShader(null);

        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(isSelected ? w * .055f : Math.max(dp(.8f), w * .018f));
        stroke.setColor(isSelected ? PINK : Color.argb(180, 174, 84, 172));
        c.drawRoundRect(r, radius, radius, stroke);
        RectF inner = new RectF(r.left + w * .10f, r.top + w * .10f,
                r.right - w * .10f, r.bottom - w * .10f);
        stroke.setStrokeWidth(Math.max(dp(.6f), w * .012f));
        stroke.setColor(Color.argb(105, 255, 166, 214));
        c.drawRoundRect(inner, radius * .72f, radius * .72f, stroke);

        paint.setColor(Color.argb(72, 255, 171, 218));
        float circuit = w * .09f;
        for (int i = 1; i <= 3; i++) {
            float y = inner.top + inner.height() * i / 4f;
            c.drawRect(inner.left, y, inner.left + circuit, y + Math.max(dp(.5f), w * .012f), paint);
            c.drawCircle(inner.left + circuit, y, Math.max(dp(.8f), w * .02f), paint);
            c.drawRect(inner.right - circuit, y, inner.right, y + Math.max(dp(.5f), w * .012f), paint);
            c.drawCircle(inner.right - circuit, y, Math.max(dp(.8f), w * .02f), paint);
        }
        drawBunnyMark(c, r.centerX(), r.centerY(), w * .48f, SOFT_PINK, PINK);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(w * .11f);
        paint.setColor(Color.argb(155, 255, 213, 235));
        c.drawText("N1GHT", r.centerX(), r.bottom - h * .10f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawBunnyMark(Canvas c, float cx, float cy, float size, int light, int accent) {
        Path ears = new Path();
        ears.moveTo(cx - size * .18f, cy - size * .10f);
        ears.cubicTo(cx - size * .42f, cy - size * .65f, cx - size * .45f, cy - size * .91f,
                cx - size * .18f, cy - size * .52f);
        ears.moveTo(cx + size * .18f, cy - size * .10f);
        ears.cubicTo(cx + size * .42f, cy - size * .65f, cx + size * .45f, cy - size * .91f,
                cx + size * .18f, cy - size * .52f);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Math.max(dp(1), size * .06f));
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setColor(accent);
        c.drawPath(ears, stroke);
        stroke.setStrokeCap(Paint.Cap.BUTT);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(30, 21, 37));
        c.drawOval(new RectF(cx - size * .38f, cy - size * .33f,
                cx + size * .38f, cy + size * .42f), paint);
        stroke.setColor(accent);
        stroke.setStrokeWidth(Math.max(dp(1), size * .05f));
        c.drawOval(new RectF(cx - size * .38f, cy - size * .33f,
                cx + size * .38f, cy + size * .42f), stroke);
        paint.setColor(light);
        c.drawCircle(cx - size * .15f, cy - size * .02f, size * .045f, paint);
        c.drawCircle(cx + size * .15f, cy - size * .02f, size * .045f, paint);
        Path teeth = new Path();
        teeth.moveTo(cx - size * .18f, cy + size * .20f);
        teeth.lineTo(cx - size * .09f, cy + size * .34f);
        teeth.lineTo(cx, cy + size * .20f);
        teeth.lineTo(cx + size * .09f, cy + size * .34f);
        teeth.lineTo(cx + size * .18f, cy + size * .20f);
        teeth.close();
        paint.setColor(accent);
        c.drawPath(teeth, paint);
    }

    private void drawActionBar(Canvas c) {
        String[] labels = {"UNDO", "HINT", "RESTART", "MENU"};
        String[] icons = {"↶", "?", "↻", "⋯"};
        for (int i = 0; i < actionRects.length; i++) {
            boolean disabled = i == 0 && !engine.canUndo();
            RectF r = actionRects[i];
            paint.setColor(disabled ? Color.rgb(20, 17, 25) : Color.rgb(28, 22, 35));
            c.drawRoundRect(r, dp(12), dp(12), paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(.8f));
            stroke.setColor(disabled ? Color.rgb(50, 43, 56) : Color.rgb(81, 62, 94));
            c.drawRoundRect(r, dp(12), dp(12), stroke);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
            paint.setTextSize(dp(17));
            paint.setColor(disabled ? Color.rgb(72, 65, 79) : SOFT_PINK);
            c.drawText(icons[i], r.centerX(), r.top + dp(24), paint);
            paint.setTextSize(dp(7.5f));
            paint.setColor(disabled ? Color.rgb(72, 65, 79) : TEXT);
            c.drawText(labels[i], r.centerX(), r.bottom - dp(9), paint);
        }
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawRoundIconButton(Canvas c, RectF r, String symbol, boolean accented) {
        paint.setColor(accented ? PINK : Color.argb(180, 29, 23, 37));
        c.drawRoundRect(r, dp(12), dp(12), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(.8f));
        stroke.setColor(accented ? SOFT_PINK : BORDER);
        c.drawRoundRect(r, dp(12), dp(12), stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(24));
        paint.setColor(TEXT);
        c.drawText(symbol, r.centerX(), r.centerY() - (paint.ascent() + paint.descent()) / 2f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawSectionHeader(Canvas c, String title, String subtitle) {
        drawAmbientBackground(c, false);
        drawRoundIconButton(c, screenBack, "‹", false);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setColor(TEXT);
        paint.setTextSize(dp(23));
        c.drawText(title, dp(62), safeTop + dp(23), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setColor(MUTED);
        paint.setTextSize(dp(10));
        c.drawText(subtitle, dp(62), safeTop + dp(41), paint);
    }

    private void drawSettings(Canvas c) {
        drawSectionHeader(c, "SETTINGS", "MAKE THE DECK FEEL RIGHT");
        drawSettingRow(c, settingRows[0], "SOUND", "Soft digital card sounds", store.sound());
        drawSettingRow(c, settingRows[1], "HAPTICS", "Gentle feedback on moves", store.haptic());
        drawSettingRow(c, settingRows[2], "REDUCED MOTION", "Calmer backgrounds and celebrations", store.reducedMotion());
        drawSettingRow(c, settingRows[3], "HIGH CONTRAST", "Brighter cards and stronger labels", store.highContrast());

        paint.setColor(PANEL);
        c.drawRoundRect(settingsAbout, dp(14), dp(14), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(BORDER);
        c.drawRoundRect(settingsAbout, dp(14), dp(14), stroke);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setColor(TEXT);
        paint.setTextSize(dp(12));
        c.drawText("ABOUT THIS GIFT", settingsAbout.left + dp(17), settingsAbout.centerY() + dp(4), paint);
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setColor(SOFT_PINK);
        paint.setTextSize(dp(19));
        c.drawText("›", settingsAbout.right - dp(17), settingsAbout.centerY() + dp(6), paint);
        paint.setTextAlign(Paint.Align.LEFT);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(9));
        paint.setColor(Color.argb(145, 196, 180, 202));
        c.drawText("LOCAL ONLY  •  NO ACCOUNT  •  NO ANALYTICS", viewWidth / 2f, safeBottom - dp(12), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawSettingRow(Canvas c, RectF r, String title, String subtitle, boolean enabled) {
        paint.setColor(PANEL);
        c.drawRoundRect(r, dp(14), dp(14), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(enabled ? Color.argb(160, 119, 70, 148) : BORDER);
        c.drawRoundRect(r, dp(14), dp(14), stroke);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setColor(TEXT);
        paint.setTextSize(dp(12));
        c.drawText(title, r.left + dp(16), r.top + dp(23), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setColor(MUTED);
        paint.setTextSize(dp(9));
        c.drawText(subtitle, r.left + dp(16), r.top + dp(42), paint);
        drawSwitch(c, new RectF(r.right - dp(60), r.centerY() - dp(14), r.right - dp(14), r.centerY() + dp(14)), enabled);
    }

    private void drawSwitch(Canvas c, RectF r, boolean on) {
        paint.setColor(on ? Color.rgb(177, 51, 135) : Color.rgb(54, 47, 61));
        c.drawRoundRect(r, r.height() / 2f, r.height() / 2f, paint);
        paint.setColor(on ? Color.rgb(255, 229, 244) : Color.rgb(154, 145, 160));
        float radius = r.height() * .36f;
        float cx = on ? r.right - r.height() / 2f : r.left + r.height() / 2f;
        c.drawCircle(cx, r.centerY(), radius, paint);
    }

    private void drawStats(Canvas c) {
        drawSectionHeader(c, "STATISTICS", "YOUR NIGHTS AT THE TABLE");
        drawStatCard(c, statCards[0], Integer.toString(store.gamesStarted()), "GAMES STARTED");
        drawStatCard(c, statCards[1], Integer.toString(store.gamesWon()), "GAMES WON");
        drawStatCard(c, statCards[2], store.winPercent() + "%", "WIN RATE");
        drawStatCard(c, statCards[3], store.currentStreak() + " / " + store.bestStreak(), "CURRENT / BEST");

        float panelWidth = Math.min(viewWidth - dp(32), dp(430));
        float left = (viewWidth - panelWidth) / 2f;
        RectF records = new RectF(left, statCards[2].bottom + dp(18), left + panelWidth, statCards[2].bottom + dp(176));
        paint.setColor(PANEL);
        c.drawRoundRect(records, dp(16), dp(16), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(BORDER);
        c.drawRoundRect(records, dp(16), dp(16), stroke);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(12));
        paint.setColor(SOFT_PINK);
        c.drawText("PERSONAL RECORDS", records.left + dp(18), records.top + dp(26), paint);
        drawRecordLine(c, records, 0, "Fastest clear", store.fastestWin() == 0 ? "—" : formatTime(store.fastestWin()));
        drawRecordLine(c, records, 1, "Fewest moves", store.fewestMoves() == 0 ? "—" : Integer.toString(store.fewestMoves()));
        drawRecordLine(c, records, 2, "Best streak", store.bestStreak() == 0 ? "—" : Integer.toString(store.bestStreak()));
    }

    private void drawStatCard(Canvas c, RectF r, String value, String label) {
        paint.setColor(PANEL);
        c.drawRoundRect(r, dp(16), dp(16), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(BORDER);
        c.drawRoundRect(r, dp(16), dp(16), stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(26));
        paint.setColor(TEXT);
        c.drawText(value, r.centerX(), r.top + dp(44), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(8));
        paint.setColor(MUTED);
        c.drawText(label, r.centerX(), r.bottom - dp(17), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawRecordLine(Canvas c, RectF records, int index, String label, String value) {
        float y = records.top + dp(61) + index * dp(35);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(11));
        paint.setColor(MUTED);
        c.drawText(label, records.left + dp(18), y, paint);
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setColor(TEXT);
        c.drawText(value, records.right - dp(18), y, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawAbout(Canvas c) {
        drawSectionHeader(c, "FOR ECHO", "A SMALL GIFT, MADE WITH LOVE");
        float cx = viewWidth / 2f;
        float emblemY = safeTop + dp(150);
        paint.setShader(new RadialGradient(cx, emblemY, dp(96),
                Color.argb(130, 194, 58, 146), Color.TRANSPARENT, Shader.TileMode.CLAMP));
        c.drawCircle(cx, emblemY, dp(96), paint);
        paint.setShader(null);
        drawBunnyMark(c, cx, emblemY, dp(92), SOFT_PINK, PINK);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(22));
        paint.setColor(TEXT);
        c.drawText("MADE FOR ECHO", cx, safeTop + dp(266), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(12));
        paint.setColor(MUTED);
        c.drawText("For quiet moments, late nights,", cx, safeTop + dp(298), paint);
        c.drawText("and every hand we keep choosing.", cx, safeTop + dp(319), paint);

        RectF note = new RectF(dp(28), safeTop + dp(352), viewWidth - dp(28), safeTop + dp(456));
        paint.setColor(Color.argb(175, 25, 20, 32));
        c.drawRoundRect(note, dp(17), dp(17), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(Color.argb(125, 119, 70, 148));
        c.drawRoundRect(note, dp(17), dp(17), stroke);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(10.5f));
        paint.setColor(Color.rgb(218, 205, 222));
        c.drawText("N1GHT D3CK is a private little solitaire deck", cx, note.top + dp(32), paint);
        c.drawText("from Cassie and CESRB Labs — no ads, no tracking,", cx, note.top + dp(53), paint);
        c.drawText("just the cards and a piece of home.", cx, note.top + dp(74), paint);

        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(9));
        paint.setColor(SOFT_PINK);
        c.drawText("N1GHT D3CK 0.2.0", cx, safeBottom - dp(25), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawGuide(Canvas c) {
        drawSectionHeader(c, "HOW TO PLAY", "KLONDIKE, KEPT SIMPLE");
        float width = Math.min(viewWidth - dp(32), dp(430));
        float left = (viewWidth - width) / 2f;
        String[] numbers = {"01", "02", "03", "04"};
        String[] titles = {"DRAW", "SELECT", "MOVE", "SEND HOME"};
        String[] bodies = {
                "Tap the deck to draw one card. When it is empty, tap again to recycle the waste.",
                "Tap a face-up card or an ordered sequence. The selected card receives a pink marker.",
                "Tap a destination column. Tableau cards descend and alternate red and black.",
                "Double-tap an eligible top card to move it to its matching foundation."
        };
        float top = safeTop + dp(72);
        for (int i = 0; i < 4; i++) {
            RectF row = new RectF(left, top + i * dp(105), left + width, top + i * dp(105) + dp(92));
            paint.setColor(PANEL);
            c.drawRoundRect(row, dp(16), dp(16), paint);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(1));
            stroke.setColor(BORDER);
            c.drawRoundRect(row, dp(16), dp(16), stroke);
            RectF badge = new RectF(row.left + dp(14), row.top + dp(17), row.left + dp(52), row.top + dp(55));
            drawChip(c, badge, numbers[i], true);
            paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
            paint.setTextSize(dp(12));
            paint.setColor(TEXT);
            c.drawText(titles[i], row.left + dp(66), row.top + dp(28), paint);
            paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            paint.setTextSize(dp(9.5f));
            paint.setColor(MUTED);
            drawWrappedText(c, bodies[i], row.left + dp(66), row.top + dp(49), row.right - dp(14), dp(15));
        }
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(9));
        paint.setColor(SOFT_PINK);
        c.drawText("UNDO, HINT, RESTART, AND SETTINGS ARE ALWAYS IN THE GAME BAR",
                viewWidth / 2f, safeBottom - dp(12), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawWin(Canvas c) {
        drawAmbientBackground(c, true);
        if (!store.reducedMotion()) postInvalidateDelayed(36);
        long time = SystemClock.uptimeMillis();
        for (int i = 0; i < 18; i++) {
            double phase = i * 1.7 + time / 900.0;
            float x = (float) ((i * 79 + Math.sin(phase) * 28 + viewWidth * 2) % viewWidth);
            float y = safeTop + dp(40) + (i * dp(39)) % Math.max(dp(160), safeBottom - safeTop - dp(260));
            float size = dp(3 + (i % 3));
            paint.setColor(i % 2 == 0 ? Color.argb(120, 242, 75, 165) : Color.argb(95, 172, 112, 210));
            c.drawCircle(x, y, size, paint);
        }

        float cx = viewWidth / 2f;
        drawBunnyMark(c, cx, safeTop + dp(165), dp(112), SOFT_PINK, PINK);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(31));
        paint.setColor(TEXT);
        c.drawText("D3CK CLEARED", cx, safeTop + dp(270), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(12));
        paint.setColor(MUTED);
        c.drawText("A perfect little victory for Echo.", cx, safeTop + dp(298), paint);

        RectF summary = new RectF(dp(36), safeTop + dp(330), viewWidth - dp(36), safeTop + dp(414));
        paint.setColor(PANEL);
        c.drawRoundRect(summary, dp(18), dp(18), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(BORDER);
        c.drawRoundRect(summary, dp(18), dp(18), stroke);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(22));
        paint.setColor(TEXT);
        c.drawText(engine.state().moves + " moves", summary.left + summary.width() * .27f, summary.top + dp(36), paint);
        c.drawText(formatTime(engine.state().elapsedSeconds), summary.left + summary.width() * .73f, summary.top + dp(36), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(8));
        paint.setColor(MUTED);
        c.drawText("MOVES", summary.left + summary.width() * .27f, summary.bottom - dp(18), paint);
        c.drawText("TIME", summary.left + summary.width() * .73f, summary.bottom - dp(18), paint);

        drawHomeButton(c, winNew, "PLAY AGAIN", "Shuffle another deck", true);
        drawHomeButton(c, winHome, "RETURN HOME", "Keep this win in your stats", false);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawGameMenu(Canvas c) {
        drawScrim(c);
        paint.setColor(Color.rgb(18, 14, 24));
        c.drawRoundRect(menuPanel, dp(20), dp(20), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(Color.rgb(99, 67, 113));
        c.drawRoundRect(menuPanel, dp(20), dp(20), stroke);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(18));
        paint.setColor(TEXT);
        c.drawText("PAUSED", menuPanel.left + dp(20), menuPanel.top + dp(34), paint);
        String[] labels = {"RESUME", "NEW DEAL", "RESTART DEAL", "SETTINGS", "RETURN HOME"};
        for (int i = 0; i < menuRows.length; i++) {
            RectF r = menuRows[i];
            paint.setColor(i == 0 ? Color.rgb(108, 39, 101) : PANEL);
            c.drawRoundRect(r, dp(12), dp(12), paint);
            stroke.setColor(i == 0 ? PINK : BORDER);
            c.drawRoundRect(r, dp(12), dp(12), stroke);
            paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
            paint.setTextSize(dp(11));
            paint.setColor(TEXT);
            c.drawText(labels[i], r.left + dp(15), r.centerY() + dp(4), paint);
            paint.setTextAlign(Paint.Align.RIGHT);
            paint.setColor(i == 0 ? TEXT : SOFT_PINK);
            c.drawText("›", r.right - dp(14), r.centerY() + dp(4), paint);
            paint.setTextAlign(Paint.Align.LEFT);
        }
    }

    private void drawConfirmation(Canvas c) {
        drawScrim(c);
        paint.setColor(Color.rgb(19, 15, 25));
        c.drawRoundRect(confirmPanel, dp(20), dp(20), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(Color.rgb(104, 70, 119));
        c.drawRoundRect(confirmPanel, dp(20), dp(20), stroke);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(19));
        paint.setColor(TEXT);
        c.drawText(confirmAction == ConfirmAction.NEW_GAME ? "START A NEW DEAL?" : "RESTART THIS DEAL?",
                confirmPanel.left + dp(20), confirmPanel.top + dp(38), paint);
        paint.setTypeface(Typeface.create("sans", Typeface.NORMAL));
        paint.setTextSize(dp(11));
        paint.setColor(MUTED);
        String line1 = confirmAction == ConfirmAction.NEW_GAME
                ? "Your current game will be replaced." : "The cards return to their original positions.";
        c.drawText(line1, confirmPanel.left + dp(20), confirmPanel.top + dp(74), paint);
        c.drawText("Your statistics stay safe.", confirmPanel.left + dp(20), confirmPanel.top + dp(96), paint);
        drawDialogButton(c, confirmCancel, "CANCEL", false);
        drawDialogButton(c, confirmAccept,
                confirmAction == ConfirmAction.NEW_GAME ? "NEW DEAL" : "RESTART", true);
    }

    private void drawDialogButton(Canvas c, RectF r, String label, boolean primary) {
        paint.setColor(primary ? Color.rgb(175, 47, 130) : PANEL_2);
        c.drawRoundRect(r, dp(12), dp(12), paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(primary ? SOFT_PINK : BORDER);
        c.drawRoundRect(r, dp(12), dp(12), stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(10));
        paint.setColor(TEXT);
        c.drawText(label, r.centerX(), r.centerY() + dp(4), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawScrim(Canvas c) {
        paint.setColor(Color.argb(205, 4, 3, 7));
        c.drawRect(0, 0, viewWidth, viewHeight, paint);
    }

    private void drawChip(Canvas c, RectF r, String label, boolean accent) {
        paint.setColor(accent ? Color.argb(130, 117, 42, 104) : PANEL);
        c.drawRoundRect(r, r.height() / 2f, r.height() / 2f, paint);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(.8f));
        stroke.setColor(accent ? Color.argb(180, 242, 75, 165) : BORDER);
        c.drawRoundRect(r, r.height() / 2f, r.height() / 2f, stroke);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextSize(dp(8));
        paint.setColor(accent ? Color.rgb(255, 217, 238) : TEXT);
        c.drawText(label, r.centerX(), r.centerY() + dp(3), paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawWrappedText(Canvas c, String text, float left, float top, float right, float lineHeight) {
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        float y = top;
        for (String word : words) {
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (paint.measureText(candidate) > right - left && line.length() > 0) {
                c.drawText(line.toString(), left, y, paint);
                line.setLength(0);
                line.append(word);
                y += lineHeight;
            } else {
                line.setLength(0);
                line.append(candidate);
            }
        }
        if (line.length() > 0) c.drawText(line.toString(), left, y, paint);
    }

    private String rankText(int rank) {
        return rank == 1 ? "A" : rank == 11 ? "J" : rank == 12 ? "Q" : rank == 13 ? "K" : Integer.toString(rank);
    }

    private String formatTime(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return hours > 0 ? String.format(Locale.US, "%d:%02d:%02d", hours, minutes, secs)
                : String.format(Locale.US, "%02d:%02d", minutes, secs);
    }

    private String ellipsize(String value, float maxWidth) {
        if (paint.measureText(value) <= maxWidth) return value;
        String suffix = "…";
        int end = value.length();
        while (end > 0 && paint.measureText(value.substring(0, end) + suffix) > maxWidth) end--;
        return end <= 0 ? suffix : value.substring(0, end) + suffix;
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP) return true;
        float x = event.getX();
        float y = event.getY();

        if (confirmAction != ConfirmAction.NONE) return handleConfirmationTap(x, y);
        if (gameMenuOpen) return handleMenuTap(x, y);

        switch (screen) {
            case HOME: return handleHomeTap(x, y);
            case GAME: return handleGameTap(x, y);
            case SETTINGS: return handleSettingsTap(x, y);
            case STATS:
                if (screenBack.contains(x, y)) { screen = Screen.HOME; invalidate(); }
                return true;
            case ABOUT:
                if (screenBack.contains(x, y)) { screen = aboutOrigin; invalidate(); }
                return true;
            case GUIDE:
                if (screenBack.contains(x, y)) { screen = Screen.HOME; invalidate(); }
                return true;
            case WIN: return handleWinTap(x, y);
            default: return true;
        }
    }

    private boolean handleHomeTap(float x, float y) {
        if (hasSavedGame && homeContinue.contains(x, y)) {
            screen = Screen.GAME;
            message = "Welcome back — your deck is exactly where you left it";
            sound(1);
            invalidate();
            return true;
        }
        if (homeContinue.contains(x, y) && !hasSavedGame) {
            requestNewGame();
            return true;
        }
        if (homeNew.contains(x, y)) {
            if (hasSavedGame) requestNewGame();
            else { screen = Screen.GUIDE; invalidate(); }
            return true;
        }
        if (homeStats.contains(x, y)) {
            screen = Screen.STATS;
            invalidate();
            return true;
        }
        if (homeSettings.contains(x, y)) {
            openSettings(Screen.HOME);
            return true;
        }
        if (homeAbout.contains(x, y)) {
            aboutOrigin = Screen.HOME;
            screen = Screen.ABOUT;
            invalidate();
            return true;
        }
        return true;
    }

    private boolean handleGameTap(float x, float y) {
        if (screenBack.contains(x, y)) {
            goHome();
            return true;
        }
        if (topMenu.contains(x, y)) {
            gameMenuOpen = true;
            invalidate();
            return true;
        }
        for (int i = 0; i < actionRects.length; i++) {
            if (!actionRects[i].contains(x, y)) continue;
            if (i == 0) {
                if (engine.undo()) moved("Move undone", 3);
                else invalid("Nothing to undo");
            } else if (i == 1) {
                message = engine.hint();
                sound(1);
                invalidate();
            } else if (i == 2) {
                requestRestart();
            } else {
                gameMenuOpen = true;
                invalidate();
            }
            return true;
        }
        if (stockRect.contains(x, y)) {
            if (engine.drawOrRecycle()) moved(engine.state().stock.isEmpty() ? "Waste ready to recycle" : "Card drawn", 0);
            else invalid("Nothing left to draw");
            return true;
        }
        if (wasteRect.contains(x, y)) {
            handleWasteTap(isDouble("waste"));
            return true;
        }
        for (int i = 0; i < 4; i++) {
            if (foundationRects[i].contains(x, y)) {
                handleFoundationTap(i, isDouble("foundation" + i));
                return true;
            }
        }
        for (int col = 0; col < 7; col++) {
            if (tableauRects[col].contains(x, y)) {
                int index = tableauIndexAt(col, y);
                handleTableauTap(col, index, isDouble("tableau" + col + ":" + index));
                return true;
            }
        }
        engine.selection.clear();
        message = "Selection cleared";
        invalidate();
        return true;
    }

    private boolean handleSettingsTap(float x, float y) {
        if (screenBack.contains(x, y)) {
            screen = settingsOrigin;
            invalidate();
            return true;
        }
        if (settingRows[0].contains(x, y)) {
            store.setSound(!store.sound());
            sound(1);
        } else if (settingRows[1].contains(x, y)) {
            store.setHaptic(!store.haptic());
            haptic();
        } else if (settingRows[2].contains(x, y)) {
            store.setReducedMotion(!store.reducedMotion());
        } else if (settingRows[3].contains(x, y)) {
            store.setHighContrast(!store.highContrast());
        } else if (settingsAbout.contains(x, y)) {
            aboutOrigin = Screen.SETTINGS;
            screen = Screen.ABOUT;
        }
        invalidate();
        return true;
    }

    private boolean handleWinTap(float x, float y) {
        if (winNew.contains(x, y)) {
            performNewGame();
        } else if (winHome.contains(x, y)) {
            goHome();
        }
        return true;
    }

    private boolean handleMenuTap(float x, float y) {
        if (!menuPanel.contains(x, y)) {
            gameMenuOpen = false;
            invalidate();
            return true;
        }
        for (int i = 0; i < menuRows.length; i++) {
            if (!menuRows[i].contains(x, y)) continue;
            gameMenuOpen = false;
            if (i == 0) invalidate();
            else if (i == 1) requestNewGame();
            else if (i == 2) requestRestart();
            else if (i == 3) openSettings(Screen.GAME);
            else goHome();
            return true;
        }
        return true;
    }

    private boolean handleConfirmationTap(float x, float y) {
        if (confirmCancel.contains(x, y) || !confirmPanel.contains(x, y)) {
            confirmAction = ConfirmAction.NONE;
            invalidate();
            return true;
        }
        if (confirmAccept.contains(x, y)) {
            ConfirmAction action = confirmAction;
            confirmAction = ConfirmAction.NONE;
            if (action == ConfirmAction.NEW_GAME) performNewGame();
            else if (action == ConfirmAction.RESTART) performRestart();
        }
        return true;
    }

    private void openSettings(Screen from) {
        settingsOrigin = from;
        screen = Screen.SETTINGS;
        invalidate();
    }

    private void goHome() {
        persist();
        screen = Screen.HOME;
        gameMenuOpen = false;
        confirmAction = ConfirmAction.NONE;
        invalidate();
    }

    private void requestNewGame() {
        if (gameInProgress && engine.state().moves > 0 && !engine.isWon()) {
            confirmAction = ConfirmAction.NEW_GAME;
            invalidate();
        } else {
            performNewGame();
        }
    }

    private void performNewGame() {
        if (gameInProgress && !engine.isWon() && engine.state().moves > 0) store.gameAbandoned();
        engine.newGame(System.currentTimeMillis());
        store.gameStarted();
        gameInProgress = true;
        hasSavedGame = true;
        screen = Screen.GAME;
        message = "Fresh deck shuffled — good luck, Echo";
        sound(5);
        persist();
        invalidate();
    }

    private void requestRestart() {
        if (engine.state().moves > 0) {
            confirmAction = ConfirmAction.RESTART;
            invalidate();
        } else {
            performRestart();
        }
    }

    private void performRestart() {
        engine.restart();
        gameInProgress = true;
        screen = Screen.GAME;
        message = "Original deal restored";
        sound(3);
        persist();
        invalidate();
    }

    private boolean isDouble(String key) {
        long now = SystemClock.uptimeMillis();
        boolean result = key.equals(lastTapKey) && now - lastTapTime < 350;
        lastTapKey = key;
        lastTapTime = now;
        return result;
    }

    private void handleWasteTap(boolean dbl) {
        if (engine.state().waste.isEmpty()) {
            invalid("Waste is empty");
            return;
        }
        if (dbl && engine.moveWasteToFoundation()) {
            moved("Moved to foundation", 4);
            return;
        }
        if (engine.selection.type == GameEngine.SourceType.WASTE) {
            engine.selection.clear();
            message = "Selection cleared";
        } else {
            engine.selectWaste();
            message = "Selected " + engine.state().waste.get(engine.state().waste.size() - 1).label();
            sound(1);
        }
        invalidate();
    }

    private void handleFoundationTap(int foundation, boolean dbl) {
        if (!engine.selection.isNone()) {
            if (engine.moveSelectionToFoundation(foundation)) moved("Foundation move", 4);
            else invalid("That card cannot go there");
            return;
        }
        if (!engine.state().foundations.get(foundation).isEmpty()) {
            engine.selectFoundation(foundation);
            message = "Foundation card selected";
            sound(1);
        } else {
            invalid("Foundation needs an Ace");
        }
        invalidate();
    }

    private int tableauIndexAt(int col, float tapY) {
        List<Card> pile = engine.state().tableau.get(col);
        if (pile.isEmpty()) return -1;
        float scale = columnScale(pile);
        float y = tableauY;
        for (int i = 0; i < pile.size(); i++) {
            float step = cardStep(pile.get(i)) * scale;
            boolean last = i == pile.size() - 1;
            if (tapY >= y && tapY < (last ? y + cardH : y + step)) return i;
            if (!last) y += step;
        }
        return pile.size() - 1;
    }

    private void handleTableauTap(int col, int index, boolean dbl) {
        List<Card> pile = engine.state().tableau.get(col);
        if (dbl && index == pile.size() - 1 && index >= 0 && pile.get(index).faceUp
                && engine.moveTableauToFoundation(col)) {
            moved("Moved to foundation", 4);
            return;
        }
        if (!engine.selection.isNone()) {
            if (engine.selection.type == GameEngine.SourceType.TABLEAU && engine.selection.pile == col) {
                engine.selection.clear();
                message = "Selection cleared";
                invalidate();
                return;
            }
            if (engine.moveSelectionToTableau(col)) moved("Cards moved", 2);
            else invalid("That sequence cannot move there");
            return;
        }
        if (index < 0) {
            invalid("Only a King can fill an empty column");
            return;
        }
        Card card = pile.get(index);
        if (!card.faceUp) {
            invalid("That card is face down");
            return;
        }
        engine.selectTableau(col, index);
        if (engine.selection.isNone()) invalid("Select a correctly ordered sequence");
        else {
            message = "Selected " + card.label();
            sound(1);
            invalidate();
        }
    }

    private void moved(String text, int tone) {
        message = text;
        sound(tone);
        haptic();
        persist();
        if (engine.isWon() && !engine.state().wonRecorded) {
            engine.state().wonRecorded = true;
            store.gameWon(engine.state().elapsedSeconds, engine.state().moves);
            persist();
            screen = Screen.WIN;
            sound(6);
        }
        invalidate();
    }

    private void invalid(String text) {
        message = text;
        sound(2);
        haptic();
        invalidate();
    }

    private void haptic() {
        if (store.haptic()) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private void sound(int kind) {
        if (!store.sound()) return;
        int tone = kind == 2 ? ToneGenerator.TONE_PROP_NACK
                : kind == 4 ? ToneGenerator.TONE_PROP_ACK
                : kind == 5 ? ToneGenerator.TONE_CDMA_PIP
                : kind == 6 ? ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD
                : ToneGenerator.TONE_PROP_BEEP;
        tones.startTone(tone, kind == 6 ? 320 : 55);
    }
}
