package com.cesrblabs.nightdeck.engine;

public enum Suit {
    CLUBS("♣", false), DIAMONDS("♦", true), HEARTS("♥", true), SPADES("♠", false);
    public final String symbol;
    public final boolean red;
    Suit(String symbol, boolean red) { this.symbol = symbol; this.red = red; }
}
