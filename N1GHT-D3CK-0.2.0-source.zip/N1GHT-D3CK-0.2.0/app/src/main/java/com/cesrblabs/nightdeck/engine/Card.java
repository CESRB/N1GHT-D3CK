package com.cesrblabs.nightdeck.engine;

import java.util.Objects;

public final class Card {
    public final Suit suit;
    public final int rank;
    public boolean faceUp;

    public Card(Suit suit, int rank, boolean faceUp) {
        if (rank < 1 || rank > 13) throw new IllegalArgumentException("rank");
        this.suit = Objects.requireNonNull(suit);
        this.rank = rank;
        this.faceUp = faceUp;
    }

    public String id() { return suit.name().charAt(0) + Integer.toString(rank); }
    public String label() {
        String r = rank == 1 ? "A" : rank == 11 ? "J" : rank == 12 ? "Q" : rank == 13 ? "K" : Integer.toString(rank);
        return r + suit.symbol;
    }
    public Card copy() { return new Card(suit, rank, faceUp); }
    @Override public boolean equals(Object other) {
        if (!(other instanceof Card)) return false;
        Card c = (Card) other;
        return suit == c.suit && rank == c.rank;
    }
    @Override public int hashCode() { return Objects.hash(suit, rank); }
    @Override public String toString() { return id() + (faceUp ? "U" : "D"); }
}
