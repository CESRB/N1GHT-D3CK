# No shrinking rules are required for the 0.2.0 testing build.
