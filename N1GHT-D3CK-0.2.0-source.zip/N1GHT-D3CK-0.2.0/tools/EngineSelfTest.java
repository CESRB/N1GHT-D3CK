import com.cesrblabs.nightdeck.engine.*;
import java.util.*;

public final class EngineSelfTest {
    private static int tests;
    private static void check(boolean value, String name) {
        tests++;
        if (!value) throw new AssertionError("FAILED: " + name);
        System.out.println("PASS " + name);
    }
    public static void main(String[] args) {
        GameState s = GameEngine.deal(42L);
        check(s.cardCount() == 52, "52 cards");
        check(s.hasExactly52UniqueCards(), "52 unique cards");
        check(s.stock.size() == 24, "24 stock cards after deal");
        for (int i = 0; i < 7; i++) {
            check(s.tableau.get(i).size() == i + 1, "tableau column " + (i + 1) + " count");
            check(s.tableau.get(i).get(i).faceUp, "tableau column " + (i + 1) + " top face up");
            for (int j = 0; j < i; j++) check(!s.tableau.get(i).get(j).faceUp, "covered card face down");
        }
        List<Card> dest = new ArrayList<>();
        dest.add(new Card(Suit.SPADES, 8, true));
        check(GameEngine.canPlaceOnTableau(new Card(Suit.HEARTS, 7, true), dest), "legal alternating tableau move");
        check(!GameEngine.canPlaceOnTableau(new Card(Suit.CLUBS, 7, true), dest), "reject same-color tableau move");
        check(GameEngine.canPlaceOnTableau(new Card(Suit.HEARTS, 13, true), new ArrayList<>()), "king to empty");
        check(!GameEngine.canPlaceOnTableau(new Card(Suit.HEARTS, 12, true), new ArrayList<>()), "reject non-king to empty");
        GameEngine e = new GameEngine(88L);
        String original = e.currentEncoded();
        check(e.drawOrRecycle(), "stock draw");
        check(e.undo(), "undo available");
        check(original.equals(e.currentEncoded()), "undo exact state");
        e.drawOrRecycle(); e.drawOrRecycle();
        String saved = e.currentEncoded();
        GameEngine r = new GameEngine(1L);
        r.restore(saved, e.originalDeal());
        check(saved.equals(r.currentEncoded()), "save restore exact");
        r.restart();
        check(r.currentEncoded().equals(r.originalDeal()), "restart original deal");
        GameEngine stock = new GameEngine(11L);
        String first = stock.state().stock.get(stock.state().stock.size() - 1).id();
        for (int i = 0; i < 24; i++) stock.drawOrRecycle();
        stock.drawOrRecycle();
        check(first.equals(stock.state().stock.get(stock.state().stock.size() - 1).id()), "waste recycle order");
        check(stock.state().hasExactly52UniqueCards(), "no duplicate/lost cards after recycle");
        System.out.println("RESULT " + tests + " engine checks passed");
    }
}
