import com.cesrblabs.nightdeck.engine.*;
import java.util.*;

public final class GameplayPersistenceAudit {
    private static int checks;

    private static void check(boolean value, String name) {
        checks++;
        if (!value) throw new AssertionError("FAILED: " + name);
    }

    private static boolean attempt(GameEngine e, Random r) {
        int op = r.nextInt(8);
        switch (op) {
            case 0: return e.drawOrRecycle();
            case 1: return e.moveWasteToFoundation();
            case 2: return e.moveWasteToTableau(r.nextInt(7));
            case 3: return e.moveTableauToFoundation(r.nextInt(7));
            case 4: return e.moveFoundationToTableau(r.nextInt(4), r.nextInt(7));
            case 5: {
                int from = r.nextInt(7);
                List<Card> pile = e.state().tableau.get(from);
                int index = pile.isEmpty() ? 0 : r.nextInt(pile.size());
                return e.moveTableauToTableau(from, index, r.nextInt(7));
            }
            case 6: return e.undo();
            default: {
                String encoded = e.currentEncoded();
                String original = e.originalDeal();
                String undo = e.undoHistoryEncoded();
                GameEngine restored = new GameEngine(-1L);
                restored.restore(encoded, original, undo);
                check(encoded.equals(restored.currentEncoded()), "session state round-trip");
                check(original.equals(restored.originalDeal()), "original deal round-trip");
                check(undo.equals(restored.undoHistoryEncoded()), "undo history round-trip");
                check(e.undoDepth() == restored.undoDepth(), "undo depth round-trip");
                return false;
            }
        }
    }


    private static GameEngine customState(List<Card> stockSeed, List<Card> waste, List<List<Card>> tableau, List<List<Card>> foundations) {
        GameState state = new GameState();
        Set<String> used = new HashSet<>();
        for (Card c : waste) { state.waste.add(c); used.add(c.id()); }
        for (int i = 0; i < 7; i++) for (Card c : tableau.get(i)) { state.tableau.get(i).add(c); used.add(c.id()); }
        for (int i = 0; i < 4; i++) for (Card c : foundations.get(i)) { state.foundations.get(i).add(c); used.add(c.id()); }
        for (Card c : stockSeed) if (used.add(c.id())) state.stock.add(c);
        for (Suit suit : Suit.values()) for (int rank = 1; rank <= 13; rank++) {
            Card c = new Card(suit, rank, false);
            if (used.add(c.id())) state.stock.add(c);
        }
        state.seed = 909090L;
        check(state.hasExactly52UniqueCards(), "custom state contains 52 unique cards");
        GameEngine e = new GameEngine(1L);
        String encoded = GameCodec.encode(state);
        e.restore(encoded, encoded, "");
        return e;
    }

    private static List<List<Card>> emptyPiles(int count) {
        List<List<Card>> out = new ArrayList<>();
        for (int i = 0; i < count; i++) out.add(new ArrayList<>());
        return out;
    }

    private static void explicitMoveCoverage() {
        List<List<Card>> tableau = emptyPiles(7);
        List<List<Card>> foundations = emptyPiles(4);
        GameEngine e = customState(Collections.emptyList(),
                List.of(new Card(Suit.HEARTS, 1, true)), tableau, foundations);
        String before = e.currentEncoded();
        check(e.moveWasteToFoundation(), "waste Ace moves to foundation");
        check(e.undo(), "undo waste-to-foundation");
        check(before.equals(e.currentEncoded()), "waste-to-foundation undo exact");

        tableau = emptyPiles(7);
        foundations = emptyPiles(4);
        tableau.get(0).add(new Card(Suit.SPADES, 8, true));
        e = customState(Collections.emptyList(), List.of(new Card(Suit.HEARTS, 7, true)), tableau, foundations);
        before = e.currentEncoded();
        e.selectWaste();
        check(e.moveSelectionToTableau(0), "selected waste moves to tableau");
        check(e.undo(), "undo selected waste move");
        check(before.equals(e.currentEncoded()), "waste-to-tableau undo exact");

        tableau = emptyPiles(7);
        foundations = emptyPiles(4);
        tableau.get(0).add(new Card(Suit.DIAMONDS, 12, false));
        tableau.get(0).add(new Card(Suit.HEARTS, 7, true));
        tableau.get(0).add(new Card(Suit.CLUBS, 6, true));
        tableau.get(1).add(new Card(Suit.SPADES, 8, true));
        e = customState(Collections.emptyList(), Collections.emptyList(), tableau, foundations);
        check(e.moveTableauToTableau(0, 1, 1), "ordered tableau sequence moves");
        check(e.state().tableau.get(0).get(0).faceUp, "sequence move exposes and flips card");
        e.verify();

        tableau = emptyPiles(7);
        foundations = emptyPiles(4);
        tableau.get(0).add(new Card(Suit.DIAMONDS, 1, true));
        e = customState(Collections.emptyList(), Collections.emptyList(), tableau, foundations);
        check(e.moveTableauToFoundation(0), "tableau Ace moves to foundation");
        e.verify();

        tableau = emptyPiles(7);
        foundations = emptyPiles(4);
        tableau.get(0).add(new Card(Suit.CLUBS, 2, true));
        foundations.get(Suit.HEARTS.ordinal()).add(new Card(Suit.HEARTS, 1, true));
        e = customState(Collections.emptyList(), Collections.emptyList(), tableau, foundations);
        before = e.currentEncoded();
        e.selectFoundation(Suit.HEARTS.ordinal());
        check(e.moveSelectionToTableau(0), "selected foundation card returns to tableau");
        check(e.undo(), "undo foundation-to-tableau");
        check(before.equals(e.currentEncoded()), "foundation-to-tableau undo exact");

        tableau = emptyPiles(7);
        foundations = emptyPiles(4);
        tableau.get(0).add(new Card(Suit.SPADES, 8, true));
        e = customState(Collections.emptyList(), List.of(new Card(Suit.CLUBS, 7, true)), tableau, foundations);
        before = e.currentEncoded();
        int depth = e.undoDepth();
        check(!e.moveWasteToTableau(0), "same-color waste move rejected");
        check(before.equals(e.currentEncoded()) && depth == e.undoDepth(), "rejected explicit move is atomic");
    }

    private static void randomizedInvariantAudit() {
        for (long seed = 1; seed <= 250; seed++) {
            GameEngine e = new GameEngine(seed * 104729L);
            Random r = new Random(seed * 8191L);
            e.verify();
            for (int step = 0; step < 700; step++) {
                String before = e.currentEncoded();
                String undoBefore = e.undoHistoryEncoded();
                boolean changed = attempt(e, r);
                e.verify();
                check(e.state().hasExactly52UniqueCards(), "52-card invariant seed " + seed + " step " + step);
                if (!changed) {
                    // Save/restore checks and rejected moves must not mutate live state.
                    check(before.equals(e.currentEncoded()), "rejected operation is atomic seed " + seed + " step " + step);
                    check(undoBefore.equals(e.undoHistoryEncoded()), "rejected operation preserves undo seed " + seed + " step " + step);
                }
            }
        }
    }

    private static void undoPersistenceAndCap() {
        GameEngine e = new GameEngine(778899L);
        List<String> snapshots = new ArrayList<>();
        snapshots.add(e.currentEncoded());
        for (int i = 0; i < 150; i++) {
            check(e.drawOrRecycle(), "draw/recycle accepted " + i);
            snapshots.add(e.currentEncoded());
        }
        check(e.undoDepth() == 100, "undo history capped at 100");

        GameEngine restored = new GameEngine(1L);
        restored.restore(e.currentEncoded(), e.originalDeal(), e.undoHistoryEncoded());
        check(restored.undoDepth() == 100, "undo cap survives save/restore");
        String current = restored.currentEncoded();
        check(current.equals(e.currentEncoded()), "restored capped session exact");

        int undone = 0;
        while (restored.undo()) {
            restored.verify();
            undone++;
        }
        check(undone == 100, "all persisted undo entries usable");
        check(!restored.canUndo(), "undo exhausted cleanly");
    }

    private static void malformedRestoreIsTransactional() {
        GameEngine e = new GameEngine(123456L);
        e.drawOrRecycle();
        String before = e.currentEncoded();
        String original = e.originalDeal();
        String undo = e.undoHistoryEncoded();

        boolean failed = false;
        try { e.restore(before, original, undo + ".not_base64!"); }
        catch (RuntimeException expected) { failed = true; }
        check(failed, "malformed undo history rejected");
        check(before.equals(e.currentEncoded()), "malformed restore leaves state untouched");
        check(original.equals(e.originalDeal()), "malformed restore leaves original untouched");
        check(undo.equals(e.undoHistoryEncoded()), "malformed restore leaves undo untouched");

        failed = false;
        try { e.restore("bad", original, undo); }
        catch (RuntimeException expected) { failed = true; }
        check(failed, "malformed current state rejected");
        check(before.equals(e.currentEncoded()), "bad current state leaves engine untouched");

        GameState structurallyInvalid = GameCodec.decode(before);
        structurallyInvalid.stock.get(0).faceUp = true;
        failed = false;
        try { e.restore(GameCodec.encode(structurallyInvalid), original, undo); }
        catch (RuntimeException expected) { failed = true; }
        check(failed, "structurally invalid state rejected");
        check(before.equals(e.currentEncoded()), "structural rejection is transactional");

        GameState negativeCounters = GameCodec.decode(before);
        negativeCounters.moves = -1;
        failed = false;
        try { e.restore(GameCodec.encode(negativeCounters), original, undo); }
        catch (RuntimeException expected) { failed = true; }
        check(failed, "negative counters rejected");
        check(before.equals(e.currentEncoded()), "counter rejection is transactional");
    }

    private static void foundationReturnAndUndo() {
        GameEngine found = null;
        int from = -1;
        for (long seed = 1; seed < 200000 && found == null; seed++) {
            GameEngine e = new GameEngine(seed);
            for (int col = 0; col < 7; col++) {
                Card c = e.state().tableau.get(col).get(e.state().tableau.get(col).size() - 1);
                if (c.rank == 1) { found = e; from = col; break; }
            }
        }
        check(found != null, "seed with exposed Ace found");
        String before = found.currentEncoded();
        check(found.moveTableauToFoundation(from), "tableau Ace to foundation");
        int foundation = found.state().foundations.get(0).isEmpty()
                ? found.state().foundations.get(1).isEmpty()
                ? found.state().foundations.get(2).isEmpty() ? 3 : 2 : 1 : 0;
        Card ace = found.state().foundations.get(foundation).get(0);
        int destination = -1;
        for (int i = 0; i < 7; i++) {
            if (GameEngine.canPlaceOnTableau(ace, found.state().tableau.get(i))) { destination = i; break; }
        }
        // An Ace normally cannot return immediately unless a matching black/red 2 is exposed.
        if (destination >= 0) {
            check(found.moveFoundationToTableau(foundation, destination), "foundation card can legally return to tableau");
            found.verify();
            check(found.undo(), "undo foundation return");
        }
        while (found.canUndo()) found.undo();
        check(before.equals(found.currentEncoded()), "multi-step undo returns exact original state");
    }

    public static void main(String[] args) {
        explicitMoveCoverage();
        randomizedInvariantAudit();
        undoPersistenceAndCap();
        malformedRestoreIsTransactional();
        foundationReturnAndUndo();
        System.out.println("RESULT " + checks + " gameplay/persistence checks passed");
    }
}
