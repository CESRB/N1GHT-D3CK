#!/usr/bin/env python3
"""Static geometry audit for NightDeckView's hand-drawn UI.

This does not replace device rendering. It checks the layout formulas against
common compact, phone, large-phone, and tablet portrait viewports in dp.
"""
from dataclasses import dataclass
from typing import List, Tuple

@dataclass(frozen=True)
class Device:
    name: str
    width: float
    height: float
    top_inset: float
    bottom_inset: float

DEVICES = [
    Device("compact-320x568", 320, 568, 24, 24),
    Device("phone-360x740", 360, 740, 24, 24),
    Device("pixel-like-393x830", 393, 830, 24, 34),
    Device("large-phone-412x892", 412, 892, 24, 34),
    Device("tablet-600x960", 600, 960, 24, 24),
]


def overlap(a: Tuple[float, float, float, float], b: Tuple[float, float, float, float]) -> bool:
    return not (a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or b[3] <= a[1])


def audit(d: Device) -> List[str]:
    errors: List[str] = []
    w, h = d.width, d.height
    safe_top = d.top_inset + 8
    safe_bottom = h - d.bottom_inset - 8
    content_h = safe_bottom - safe_top
    compact_h = content_h < 620
    compact_w = w < 350

    # Home geometry mirrors computeLayout()/drawHome().
    button_w = min(w - 40, 380)
    button_left = (w - button_w) / 2
    button_h = 56
    usable = max(520, content_h)
    home_top = safe_top + usable * 0.58
    required = button_h * 2 + 121
    if home_top + required > safe_bottom:
        home_top = safe_bottom - required
    continue_r = (button_left, home_top, button_left + button_w, home_top + button_h)
    new_r = (button_left, continue_r[3] + 11, button_left + button_w, continue_r[3] + 67)
    stats_r = (button_left, new_r[3] + 12, button_left + (button_w - 10) / 2, new_r[3] + 64)
    about_r = (button_left + button_w * .22, stats_r[3] + 8,
               button_left + button_w * .78, stats_r[3] + 46)

    hero_y = safe_top + (185 if compact_h else min(292, content_h * .36))
    hero_w = min(76, w * .22) if compact_h else min(104, w * .245)
    hero_h = hero_w * 1.46
    hero_box = (w/2 - hero_w * 1.3, hero_y - hero_h * .57,
                w/2 + hero_w * 1.3, hero_y + hero_h * .72)
    brand_w = min(w - (72 if compact_h else 48), 250 if compact_h else 360)
    brand_h = brand_w * 375 / 835
    brand_top = safe_top + (8 if compact_h else 10)
    brand_box = (w/2 - brand_w/2, brand_top,
                 w/2 + brand_w/2, brand_top + brand_h)

    if about_r[3] > safe_bottom + .01:
        errors.append(f"home content exceeds safe bottom by {about_r[3] - safe_bottom:.1f}dp")
    if overlap(brand_box, hero_box):
        errors.append("brand lockup overlaps hero card cluster")
    if hero_box[3] > continue_r[1]:
        errors.append(f"hero overlaps primary action by {hero_box[3] - continue_r[1]:.1f}dp")
    for label, r in [("continue", continue_r), ("new", new_r), ("stats", stats_r), ("about", about_r)]:
        if r[3] - r[1] < 38:
            errors.append(f"{label} touch target is under 38dp")

    # Game header: back, title, metrics, menu.
    top_menu_left = w - 52
    timer_w = 58 if compact_w else 68
    moves_w = 48 if compact_w else 52
    timer_right = top_menu_left - 6
    timer = (timer_right - timer_w, safe_top + 6, timer_right, safe_top + 42)
    moves = (timer[0] - 6 - moves_w, safe_top + 6, timer[0] - 6, safe_top + 42)
    approximate_title_right = 60 + (82 if compact_w else 96)
    if approximate_title_right > moves[0] - 4:
        errors.append("game title crowds move metric")
    if timer[2] > top_menu_left:
        errors.append("timer overlaps menu")

    # Game board and action bar.
    board_w = min(w - 16, 520)
    gap = max(3, min(6, board_w * .012))
    card_w = (board_w - gap * 6) / 7
    card_h = card_w * 1.46
    pile_y = safe_top + 88
    tableau_y = pile_y + card_h + 17
    bottom_bar_top = safe_bottom - 58
    tableau_bottom = bottom_bar_top - 8
    if card_w < 38:
        errors.append(f"cards too narrow ({card_w:.1f}dp)")
    if tableau_bottom - tableau_y < 190:
        errors.append("tableau vertical space is too small")

    # Win screen compact/normal layout.
    summary_top = safe_top + (214 if compact_h else 330)
    summary_bottom = summary_top + (68 if compact_h else 84)
    win_new_top = safe_bottom - 136
    if summary_bottom > win_new_top - 12:
        errors.append("win summary crowds Play Again button")

    # Settings and guide screens.
    content_top = safe_top + 74
    settings_last_bottom = content_top + 3 * 69 + 58
    settings_about_bottom = settings_last_bottom + 72
    if settings_about_bottom > safe_bottom:
        errors.append("settings content exceeds safe bottom")
    guide_last_bottom = safe_top + 72 + 3 * 105 + 92
    if guide_last_bottom > safe_bottom - 18:
        errors.append("guide rows crowd footer")

    return errors


def main() -> int:
    total = 0
    for d in DEVICES:
        errors = audit(d)
        if errors:
            print(f"FAIL {d.name}")
            for e in errors:
                print(f"  - {e}")
            total += len(errors)
        else:
            print(f"PASS {d.name}")
    if total:
        print(f"RESULT {total} layout issue(s) found")
        return 1
    print(f"RESULT {len(DEVICES)} viewport profiles passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
