import android.content.Context;
import android.content.SharedPreferences;
import com.cesrblabs.nightdeck.StatsStore;
import com.cesrblabs.nightdeck.engine.*;
import java.util.*;

public final class PersistenceStoreSelfTest {
    private static int checks;
    private static void check(boolean value, String name) {
        checks++;
        if (!value) throw new AssertionError("FAILED: " + name);
        System.out.println("PASS " + name);
    }

    private static final class MemoryPreferences implements SharedPreferences {
        private final Map<String,Object> values = new HashMap<>();
        @Override public boolean getBoolean(String k, boolean d) { Object v=values.get(k); return v instanceof Boolean ? (Boolean)v : d; }
        @Override public String getString(String k, String d) { Object v=values.get(k); return v instanceof String ? (String)v : d; }
        @Override public int getInt(String k, int d) { Object v=values.get(k); return v instanceof Integer ? (Integer)v : d; }
        @Override public long getLong(String k, long d) { Object v=values.get(k); return v instanceof Long ? (Long)v : d; }
        @Override public boolean contains(String k) { return values.containsKey(k); }
        @Override public Editor edit() { return new MemoryEditor(); }
        void rawPut(String key, Object value) { values.put(key, value); }
        private final class MemoryEditor implements Editor {
            private final Map<String,Object> writes = new HashMap<>();
            private final Set<String> removals = new HashSet<>();
            @Override public Editor putBoolean(String k, boolean v) { writes.put(k,v); removals.remove(k); return this; }
            @Override public Editor putString(String k, String v) { writes.put(k,v); removals.remove(k); return this; }
            @Override public Editor putInt(String k, int v) { writes.put(k,v); removals.remove(k); return this; }
            @Override public Editor putLong(String k, long v) { writes.put(k,v); removals.remove(k); return this; }
            @Override public Editor remove(String k) { removals.add(k); writes.remove(k); return this; }
            @Override public void apply() { for (String k: removals) values.remove(k); values.putAll(writes); }
        }
    }

    private static final class FakeContext extends Context {
        final MemoryPreferences prefs = new MemoryPreferences();
        @Override public SharedPreferences getSharedPreferences(String n, int m) { return prefs; }
    }

    private static void makeWon(GameEngine e, int moves, long seconds) {
        GameState s = e.state();
        s.stock.clear(); s.waste.clear();
        for (List<Card> p : s.tableau) p.clear();
        for (List<Card> p : s.foundations) p.clear();
        for (Suit suit : Suit.values()) for (int rank=1; rank<=13; rank++)
            s.foundations.get(suit.ordinal()).add(new Card(suit, rank, true));
        s.moves = moves;
        s.elapsedSeconds = seconds;
        e.verify();
    }

    public static void main(String[] args) {
        FakeContext context = new FakeContext();
        StatsStore store = new StatsStore(context);
        check(store.sound() && store.haptic(), "settings defaults");
        check(!store.reducedMotion() && !store.highContrast(), "accessibility defaults");
        store.setSound(false); store.setHaptic(false); store.setReducedMotion(true); store.setHighContrast(true);
        StatsStore reopened = new StatsStore(context);
        check(!reopened.sound() && !reopened.haptic(), "sound and haptic persist");
        check(reopened.reducedMotion() && reopened.highContrast(), "accessibility settings persist");

        GameEngine original = new GameEngine(555L);
        original.drawOrRecycle(); original.drawOrRecycle(); original.drawOrRecycle();
        String exact = original.currentEncoded();
        String undo = original.undoHistoryEncoded();
        reopened.saveGame(original);
        check(reopened.hasSavedGame(), "active game save exists");
        GameEngine restored = new GameEngine(1L);
        check(reopened.loadGame(restored), "active game loads");
        check(exact.equals(restored.currentEncoded()), "game state persists exactly");
        check(undo.equals(restored.undoHistoryEncoded()), "undo history persists exactly");
        check(restored.undo(), "persisted undo is usable");

        context.prefs.rawPut("game", "corrupt");
        GameEngine protectedEngine = new GameEngine(999L);
        String protectedBefore = protectedEngine.currentEncoded();
        check(!reopened.loadGame(protectedEngine), "corrupt save rejected");
        check(protectedBefore.equals(protectedEngine.currentEncoded()), "corrupt save does not mutate engine");
        check(!reopened.hasSavedGame(), "corrupt save is cleared");

        reopened.gameStarted();
        GameEngine winner = new GameEngine(77L);
        winner.drawOrRecycle();
        reopened.saveGame(winner);
        makeWon(winner, 84, 321);
        reopened.recordWin(winner);
        check(winner.state().wonRecorded, "win marked in memory");
        check(!reopened.hasSavedGame(), "completed deal removed from continue slot");
        check(reopened.gamesStarted() == 1 && reopened.gamesWon() == 1, "win statistics recorded");
        check(reopened.currentStreak() == 1 && reopened.bestStreak() == 1, "first streak recorded");
        check(reopened.fastestWin() == 321 && reopened.fewestMoves() == 84, "first records recorded");

        reopened.gameStarted();
        GameEngine faster = new GameEngine(78L);
        makeWon(faster, 70, 280);
        reopened.recordWin(faster);
        check(reopened.gamesWon() == 2 && reopened.currentStreak() == 2 && reopened.bestStreak() == 2, "second win extends streak");
        check(reopened.fastestWin() == 280 && reopened.fewestMoves() == 70, "better records replace old records");
        reopened.gameAbandoned();
        check(reopened.currentStreak() == 0 && reopened.bestStreak() == 2, "abandon resets only current streak");
        check(reopened.winPercent() == 100, "win percentage calculation");

        System.out.println("RESULT " + checks + " persistence/store checks passed");
    }
}
