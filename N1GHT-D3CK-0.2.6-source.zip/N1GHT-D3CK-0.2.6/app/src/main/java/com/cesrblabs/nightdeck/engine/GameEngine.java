package com.cesrblabs.nightdeck.engine;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.Random;

public final class GameEngine {
    public enum SourceType { NONE, WASTE, TABLEAU, FOUNDATION }

    public static final class Selection {
        public SourceType type = SourceType.NONE;
        public int pile = -1;
        public int index = -1;
        public void clear() { type = SourceType.NONE; pile = -1; index = -1; }
        public boolean isNone() { return type == SourceType.NONE; }
    }

    private GameState state;
    private String originalDeal;
    private final Deque<String> undo = new ArrayDeque<>();
    public final Selection selection = new Selection();

    public GameEngine(long seed) { newGame(seed); }

    public GameState state() { return state; }
    public String originalDeal() { return originalDeal; }
    public boolean canUndo() { return !undo.isEmpty(); }

    public void newGame(long seed) {
        state = deal(seed);
        originalDeal = GameCodec.encode(state);
        undo.clear();
        selection.clear();
    }

    public static GameState deal(long seed) {
        List<Card> deck = new ArrayList<>(52);
        for (Suit suit : Suit.values()) for (int rank = 1; rank <= 13; rank++) deck.add(new Card(suit, rank, false));
        Collections.shuffle(deck, new Random(seed));
        GameState s = new GameState();
        s.seed = seed;
        int cursor = 0;
        for (int col = 0; col < 7; col++) {
            for (int row = 0; row <= col; row++) {
                Card c = deck.get(cursor++);
                c.faceUp = row == col;
                s.tableau.get(col).add(c);
            }
        }
        while (cursor < deck.size()) s.stock.add(deck.get(cursor++));
        if (!s.hasExactly52UniqueCards()) throw new IllegalStateException("Deal invariant failed");
        return s;
    }

    public void restore(String encoded, String original) {
        restore(encoded, original, "");
    }

    /**
     * Restores a complete playable session. The undo history is stored as
     * dot-separated URL-safe Base64 state snapshots, newest first.
     * Older saves that do not contain history remain valid.
     */
    public void restore(String encoded, String original, String encodedUndoHistory) {
        GameState restored = GameCodec.decode(encoded);
        GameState originalState = GameCodec.decode(original);
        verifyState(restored);
        verifyState(originalState);
        Deque<String> restoredUndo = new ArrayDeque<>();
        if (encodedUndoHistory != null && !encodedUndoHistory.isEmpty()) {
            String[] snapshots = encodedUndoHistory.split("\\.", -1);
            if (snapshots.length > 100) throw new IllegalArgumentException("Undo history exceeds limit");
            for (String snapshot : snapshots) {
                if (snapshot.isEmpty()) throw new IllegalArgumentException("Invalid empty undo snapshot");
                GameState undoState = GameCodec.decode(snapshot);
                verifyState(undoState); // validate before mutating the live engine
                restoredUndo.addLast(snapshot);
            }
        }
        state = restored;
        originalDeal = GameCodec.encode(originalState);
        undo.clear();
        undo.addAll(restoredUndo);
        selection.clear();
        verify();
    }

    public String undoHistoryEncoded() {
        if (undo.isEmpty()) return "";
        StringBuilder out = new StringBuilder();
        for (String snapshot : undo) {
            if (out.length() > 0) out.append('.');
            out.append(snapshot);
        }
        return out.toString();
    }

    public int undoDepth() { return undo.size(); }

    public void restart() {
        state = GameCodec.decode(originalDeal);
        undo.clear();
        selection.clear();
    }

    public boolean undo() {
        if (undo.isEmpty()) return false;
        state = GameCodec.decode(undo.pop());
        selection.clear();
        return true;
    }

    private void beforeMove() {
        undo.push(GameCodec.encode(state));
        while (undo.size() > 100) undo.removeLast();
    }

    private void rejectMove() {
        if (!undo.isEmpty()) undo.pop();
    }

    private boolean finishMove(boolean changed, boolean countMove) {
        if (!changed) { rejectMove(); return false; }
        if (countMove) state.moves++;
        selection.clear();
        verify();
        return true;
    }

    public boolean drawOrRecycle() {
        beforeMove();
        if (!state.stock.isEmpty()) {
            Card c = state.stock.remove(state.stock.size() - 1);
            c.faceUp = true;
            state.waste.add(c);
            return finishMove(true, true);
        }
        if (state.waste.isEmpty()) return finishMove(false, false);
        while (!state.waste.isEmpty()) {
            Card c = state.waste.remove(state.waste.size() - 1);
            c.faceUp = false;
            state.stock.add(c);
        }
        return finishMove(true, true);
    }

    public boolean moveWasteToTableau(int to) {
        if (state.waste.isEmpty() || to < 0 || to > 6) return false;
        Card card = state.waste.get(state.waste.size() - 1);
        if (!canPlaceOnTableau(card, state.tableau.get(to))) return false;
        beforeMove();
        state.tableau.get(to).add(state.waste.remove(state.waste.size() - 1));
        return finishMove(true, true);
    }

    public boolean moveWasteToFoundation() {
        if (state.waste.isEmpty()) return false;
        Card card = state.waste.get(state.waste.size() - 1);
        if (!canPlaceOnFoundation(card)) return false;
        beforeMove();
        state.foundations.get(card.suit.ordinal()).add(state.waste.remove(state.waste.size() - 1));
        return finishMove(true, true);
    }

    public boolean moveTableauToTableau(int from, int index, int to) {
        if (from < 0 || from > 6 || to < 0 || to > 6 || from == to) return false;
        List<Card> source = state.tableau.get(from);
        if (index < 0 || index >= source.size()) return false;
        Card first = source.get(index);
        if (!first.faceUp || !isValidFaceUpSequence(source, index) || !canPlaceOnTableau(first, state.tableau.get(to))) return false;
        beforeMove();
        List<Card> moving = new ArrayList<>(source.subList(index, source.size()));
        source.subList(index, source.size()).clear();
        state.tableau.get(to).addAll(moving);
        autoFlip(from);
        return finishMove(true, true);
    }

    public boolean moveTableauToFoundation(int from) {
        if (from < 0 || from > 6 || state.tableau.get(from).isEmpty()) return false;
        List<Card> source = state.tableau.get(from);
        Card card = source.get(source.size() - 1);
        if (!card.faceUp || !canPlaceOnFoundation(card)) return false;
        beforeMove();
        state.foundations.get(card.suit.ordinal()).add(source.remove(source.size() - 1));
        autoFlip(from);
        return finishMove(true, true);
    }

    public boolean moveFoundationToTableau(int foundation, int to) {
        if (foundation < 0 || foundation > 3 || to < 0 || to > 6) return false;
        List<Card> source = state.foundations.get(foundation);
        if (source.isEmpty()) return false;
        Card card = source.get(source.size() - 1);
        if (!canPlaceOnTableau(card, state.tableau.get(to))) return false;
        beforeMove();
        state.tableau.get(to).add(source.remove(source.size() - 1));
        return finishMove(true, true);
    }

    public boolean autoMoveToFoundation(SourceType type, int pile) {
        return type == SourceType.WASTE ? moveWasteToFoundation() : type == SourceType.TABLEAU && moveTableauToFoundation(pile);
    }

    public static boolean canPlaceOnTableau(Card moving, List<Card> destination) {
        if (destination.isEmpty()) return moving.rank == 13;
        Card top = destination.get(destination.size() - 1);
        return top.faceUp && top.rank == moving.rank + 1 && top.suit.red != moving.suit.red;
    }

    public boolean canPlaceOnFoundation(Card card) {
        List<Card> f = state.foundations.get(card.suit.ordinal());
        return f.isEmpty() ? card.rank == 1 : f.get(f.size() - 1).rank + 1 == card.rank;
    }

    public static boolean isValidFaceUpSequence(List<Card> pile, int start) {
        for (int i = start; i < pile.size(); i++) if (!pile.get(i).faceUp) return false;
        for (int i = start; i < pile.size() - 1; i++) {
            Card a = pile.get(i), b = pile.get(i + 1);
            if (a.rank != b.rank + 1 || a.suit.red == b.suit.red) return false;
        }
        return true;
    }

    private void autoFlip(int column) {
        List<Card> pile = state.tableau.get(column);
        if (!pile.isEmpty()) pile.get(pile.size() - 1).faceUp = true;
    }

    public boolean isWon() {
        for (List<Card> f : state.foundations) if (f.size() != 13) return false;
        return true;
    }

    public String hint() {
        if (!state.waste.isEmpty()) {
            Card w = state.waste.get(state.waste.size() - 1);
            if (canPlaceOnFoundation(w)) return "Send " + w.label() + " to its foundation";
            for (int i = 0; i < 7; i++) if (canPlaceOnTableau(w, state.tableau.get(i))) return "Move " + w.label() + " from waste to column " + (i + 1);
        }
        for (int from = 0; from < 7; from++) {
            List<Card> pile = state.tableau.get(from);
            if (!pile.isEmpty() && canPlaceOnFoundation(pile.get(pile.size() - 1))) return "Send " + pile.get(pile.size() - 1).label() + " to its foundation";
            for (int index = 0; index < pile.size(); index++) {
                if (!pile.get(index).faceUp || !isValidFaceUpSequence(pile, index)) continue;
                for (int to = 0; to < 7; to++) if (to != from && canPlaceOnTableau(pile.get(index), state.tableau.get(to)))
                    return "Move " + pile.get(index).label() + " and its sequence to column " + (to + 1);
            }
        }
        if (!state.stock.isEmpty()) return "Draw from the stock";
        if (!state.waste.isEmpty()) return "Recycle the waste";
        return "No legal move found";
    }

    public void selectWaste() {
        if (state.waste.isEmpty()) { selection.clear(); return; }
        selection.type = SourceType.WASTE; selection.pile = 0; selection.index = state.waste.size() - 1;
    }

    public void selectTableau(int pile, int index) {
        if (pile < 0 || pile > 6) { selection.clear(); return; }
        List<Card> p = state.tableau.get(pile);
        if (index < 0 || index >= p.size() || !p.get(index).faceUp || !isValidFaceUpSequence(p, index)) { selection.clear(); return; }
        selection.type = SourceType.TABLEAU; selection.pile = pile; selection.index = index;
    }

    public void selectFoundation(int pile) {
        if (pile < 0 || pile > 3 || state.foundations.get(pile).isEmpty()) { selection.clear(); return; }
        selection.type = SourceType.FOUNDATION; selection.pile = pile; selection.index = state.foundations.get(pile).size() - 1;
    }

    public boolean moveSelectionToTableau(int to) {
        if (selection.type == SourceType.WASTE) return moveWasteToTableau(to);
        if (selection.type == SourceType.TABLEAU) return moveTableauToTableau(selection.pile, selection.index, to);
        if (selection.type == SourceType.FOUNDATION) return moveFoundationToTableau(selection.pile, to);
        return false;
    }

    public boolean moveSelectionToFoundation(int foundation) {
        if (selection.type == SourceType.WASTE) {
            if (state.waste.isEmpty() || state.waste.get(state.waste.size() - 1).suit.ordinal() != foundation) return false;
            return moveWasteToFoundation();
        }
        if (selection.type == SourceType.TABLEAU) {
            List<Card> p = state.tableau.get(selection.pile);
            if (selection.index != p.size() - 1 || p.get(selection.index).suit.ordinal() != foundation) return false;
            return moveTableauToFoundation(selection.pile);
        }
        return false;
    }

    public String currentEncoded() { return GameCodec.encode(state); }

    public void verify() { verifyState(state); }

    private static void verifyState(GameState candidate) {
        if (!candidate.hasExactly52UniqueCards()) throw new IllegalStateException("Card uniqueness invariant failed");
        if (candidate.moves < 0 || candidate.elapsedSeconds < 0)
            throw new IllegalStateException("Negative counters are invalid");
        for (Card c : candidate.stock) if (c.faceUp)
            throw new IllegalStateException("Stock cards must be face down");
        for (Card c : candidate.waste) if (!c.faceUp)
            throw new IllegalStateException("Waste cards must be face up");
        for (List<Card> pile : candidate.tableau) {
            boolean seenUp = false;
            for (Card c : pile) {
                if (c.faceUp) seenUp = true;
                else if (seenUp) throw new IllegalStateException("Face-down card above face-up card");
            }
            int firstUp = -1;
            for (int i = 0; i < pile.size(); i++) if (pile.get(i).faceUp) { firstUp = i; break; }
            if (firstUp >= 0 && !isValidFaceUpSequence(pile, firstUp)) throw new IllegalStateException("Invalid tableau sequence");
        }
        for (int i = 0; i < 4; i++) {
            List<Card> f = candidate.foundations.get(i);
            for (int j = 0; j < f.size(); j++) {
                Card c = f.get(j);
                if (c.suit.ordinal() != i || c.rank != j + 1 || !c.faceUp) throw new IllegalStateException("Invalid foundation");
            }
        }
    }
}
