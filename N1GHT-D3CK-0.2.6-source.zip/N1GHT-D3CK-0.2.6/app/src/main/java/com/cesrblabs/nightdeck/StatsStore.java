package com.cesrblabs.nightdeck;

import android.content.Context;
import android.content.SharedPreferences;
import com.cesrblabs.nightdeck.engine.GameEngine;

public final class StatsStore {
    private final SharedPreferences prefs;
    public StatsStore(Context context) { prefs = context.getSharedPreferences("nightdeck", Context.MODE_PRIVATE); }

    public boolean sound() { return prefs.getBoolean("sound", true); }
    public boolean haptic() { return prefs.getBoolean("haptic", true); }
    public boolean reducedMotion() { return prefs.getBoolean("reduced_motion", false); }
    public boolean highContrast() { return prefs.getBoolean("high_contrast", false); }
    public void setSound(boolean v) { prefs.edit().putBoolean("sound", v).apply(); }
    public void setHaptic(boolean v) { prefs.edit().putBoolean("haptic", v).apply(); }
    public void setReducedMotion(boolean v) { prefs.edit().putBoolean("reduced_motion", v).apply(); }
    public void setHighContrast(boolean v) { prefs.edit().putBoolean("high_contrast", v).apply(); }

    public void saveGame(GameEngine engine) {
        prefs.edit()
                .putString("game", engine.currentEncoded())
                .putString("original", engine.originalDeal())
                .putString("undo", engine.undoHistoryEncoded())
                .apply();
    }

    public void clearSavedGame() {
        prefs.edit().remove("game").remove("original").remove("undo").apply();
    }
    public boolean hasSavedGame() { return prefs.contains("game") && prefs.contains("original"); }
    public boolean loadGame(GameEngine engine) {
        try {
            String game = prefs.getString("game", null), original = prefs.getString("original", null);
            String undo = prefs.getString("undo", "");
            if (game == null || original == null) return false;
            engine.restore(game, original, undo);
            return true;
        } catch (RuntimeException badSave) {
            clearSavedGame();
            return false;
        }
    }

    public void gameStarted() {
        prefs.edit().putInt("games_started", gamesStarted() + 1).apply();
    }
    /**
     * Records a win and removes the completed active save in one preference
     * transaction so a finished game cannot reappear as "Continue Game".
     */
    public void recordWin(GameEngine engine) {
        engine.state().wonRecorded = true;
        long seconds = engine.state().elapsedSeconds;
        int moves = engine.state().moves;
        int current = currentStreak() + 1;
        SharedPreferences.Editor e = prefs.edit()
                .remove("game")
                .remove("original")
                .remove("undo")
                .putInt("games_won", gamesWon() + 1)
                .putInt("current_streak", current)
                .putInt("best_streak", Math.max(bestStreak(), current));
        long fastest = fastestWin();
        if (fastest == 0 || seconds < fastest) e.putLong("fastest_win", seconds);
        int fewest = fewestMoves();
        if (fewest == 0 || moves < fewest) e.putInt("fewest_moves", moves);
        e.apply();
    }
    public void gameAbandoned() {
        if (currentStreak() != 0) prefs.edit().putInt("current_streak", 0).apply();
    }

    public int gamesStarted() { return prefs.getInt("games_started", 0); }
    public int gamesWon() { return prefs.getInt("games_won", 0); }
    public int currentStreak() { return prefs.getInt("current_streak", 0); }
    public int bestStreak() { return prefs.getInt("best_streak", 0); }
    public long fastestWin() { return prefs.getLong("fastest_win", 0); }
    public int fewestMoves() { return prefs.getInt("fewest_moves", 0); }
    public int winPercent() { return gamesStarted() == 0 ? 0 : Math.round(gamesWon() * 100f / gamesStarted()); }
}
