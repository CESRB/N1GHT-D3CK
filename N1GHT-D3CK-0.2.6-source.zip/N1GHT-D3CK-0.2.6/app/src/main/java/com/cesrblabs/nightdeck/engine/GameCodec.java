package com.cesrblabs.nightdeck.engine;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public final class GameCodec {
    private GameCodec() {}

    public static String encode(GameState s) {
        StringBuilder b = new StringBuilder();
        b.append(s.seed).append(';').append(s.moves).append(';').append(s.elapsedSeconds).append(';').append(s.wonRecorded ? 1 : 0).append('|');
        writePile(b, s.stock); b.append('|');
        writePile(b, s.waste); b.append('|');
        for (int i = 0; i < 7; i++) { writePile(b, s.tableau.get(i)); b.append('|'); }
        for (int i = 0; i < 4; i++) { writePile(b, s.foundations.get(i)); if (i < 3) b.append('|'); }
        return Base64.getUrlEncoder().withoutPadding().encodeToString(b.toString().getBytes(StandardCharsets.UTF_8));
    }

    public static GameState decode(String encoded) {
        String raw = new String(Base64.getUrlDecoder().decode(encoded), StandardCharsets.UTF_8);
        String[] sections = raw.split("\\|", -1);
        if (sections.length != 14) throw new IllegalArgumentException("Invalid state section count");
        String[] meta = sections[0].split(";", -1);
        if (meta.length < 3 || meta.length > 4) throw new IllegalArgumentException("Invalid state metadata");
        GameState s = new GameState();
        s.seed = Long.parseLong(meta[0]);
        s.moves = Integer.parseInt(meta[1]);
        s.elapsedSeconds = Long.parseLong(meta[2]);
        if (s.moves < 0 || s.elapsedSeconds < 0) throw new IllegalArgumentException("Negative state counters");
        if (meta.length == 4 && !("0".equals(meta[3]) || "1".equals(meta[3])))
            throw new IllegalArgumentException("Invalid win marker");
        s.wonRecorded = meta.length > 3 && "1".equals(meta[3]);
        readPile(sections[1], s.stock);
        readPile(sections[2], s.waste);
        for (int i = 0; i < 7; i++) readPile(sections[3 + i], s.tableau.get(i));
        for (int i = 0; i < 4; i++) readPile(sections[10 + i], s.foundations.get(i));
        if (!s.hasExactly52UniqueCards()) throw new IllegalArgumentException("State does not contain 52 unique cards");
        return s;
    }

    private static void writePile(StringBuilder b, List<Card> pile) {
        for (int i = 0; i < pile.size(); i++) {
            Card c = pile.get(i);
            if (i > 0) b.append(',');
            b.append(c.suit.ordinal()).append(':').append(c.rank).append(':').append(c.faceUp ? 1 : 0);
        }
    }

    private static void readPile(String raw, List<Card> out) {
        if (raw.isEmpty()) return;
        for (String token : raw.split(",", -1)) {
            String[] p = token.split(":", -1);
            if (p.length != 3) throw new IllegalArgumentException("Invalid card token");
            int suit = Integer.parseInt(p[0]);
            int rank = Integer.parseInt(p[1]);
            if (suit < 0 || suit >= Suit.values().length || rank < 1 || rank > 13)
                throw new IllegalArgumentException("Card outside valid range");
            if (!("0".equals(p[2]) || "1".equals(p[2])))
                throw new IllegalArgumentException("Invalid face-up marker");
            out.add(new Card(Suit.values()[suit], rank, "1".equals(p[2])));
        }
    }
}
