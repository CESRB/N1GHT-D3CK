package com.cesrblabs.nightdeck.engine;

import org.junit.Test;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import static org.junit.Assert.*;

public class GameEngineTest {
    @Test public void deckContains52UniqueCards() {
        GameState s = GameEngine.deal(42L);
        assertEquals(52, s.cardCount());
        assertTrue(s.hasExactly52UniqueCards());
    }

    @Test public void initialDealHasCorrectColumnsAndFaceUpCards() {
        GameState s = GameEngine.deal(7L);
        for (int i = 0; i < 7; i++) {
            assertEquals(i + 1, s.tableau.get(i).size());
            for (int j = 0; j < i; j++) assertFalse(s.tableau.get(i).get(j).faceUp);
            assertTrue(s.tableau.get(i).get(i).faceUp);
        }
        assertEquals(24, s.stock.size());
        assertTrue(s.waste.isEmpty());
    }

    @Test public void shuffleIsDeterministicForSeed() {
        assertEquals(GameCodec.encode(GameEngine.deal(991L)), GameCodec.encode(GameEngine.deal(991L)));
        assertNotEquals(GameCodec.encode(GameEngine.deal(991L)), GameCodec.encode(GameEngine.deal(992L)));
    }

    @Test public void legalAndIllegalTableauRules() {
        List<Card> blackEight = new ArrayList<>();
        blackEight.add(new Card(Suit.SPADES, 8, true));
        assertTrue(GameEngine.canPlaceOnTableau(new Card(Suit.HEARTS, 7, true), blackEight));
        assertFalse(GameEngine.canPlaceOnTableau(new Card(Suit.DIAMONDS, 8, true), blackEight));
        assertFalse(GameEngine.canPlaceOnTableau(new Card(Suit.CLUBS, 7, true), blackEight));
        assertFalse(GameEngine.canPlaceOnTableau(new Card(Suit.HEARTS, 6, true), blackEight));
    }

    @Test public void emptyColumnAcceptsOnlyKing() {
        assertTrue(GameEngine.canPlaceOnTableau(new Card(Suit.HEARTS, 13, true), new ArrayList<>()));
        assertFalse(GameEngine.canPlaceOnTableau(new Card(Suit.HEARTS, 12, true), new ArrayList<>()));
    }

    @Test public void orderedSequenceValidation() {
        List<Card> sequence = List.of(
                new Card(Suit.SPADES, 9, true),
                new Card(Suit.HEARTS, 8, true),
                new Card(Suit.CLUBS, 7, true));
        assertTrue(GameEngine.isValidFaceUpSequence(sequence, 0));
        sequence.get(2).faceUp = false;
        assertFalse(GameEngine.isValidFaceUpSequence(sequence, 0));
    }

    @Test public void foundationRequiresAceThenSameSuitAscending() {
        GameEngine e = new GameEngine(1L);
        assertFalse(e.canPlaceOnFoundation(new Card(Suit.HEARTS, 2, true)));
        assertTrue(e.canPlaceOnFoundation(new Card(Suit.HEARTS, 1, true)));
        e.state().foundations.get(Suit.HEARTS.ordinal()).add(new Card(Suit.HEARTS, 1, true));
        assertTrue(e.canPlaceOnFoundation(new Card(Suit.HEARTS, 2, true)));
        assertFalse(e.canPlaceOnFoundation(new Card(Suit.DIAMONDS, 2, true)));
        assertFalse(e.canPlaceOnFoundation(new Card(Suit.HEARTS, 3, true)));
    }

    @Test public void stockDrawAndWasteRecyclePreserveOrderAndCards() {
        GameEngine e = new GameEngine(44L);
        String firstTop = e.state().stock.get(e.state().stock.size() - 1).id();
        for (int i = 0; i < 24; i++) assertTrue(e.drawOrRecycle());
        assertEquals(0, e.state().stock.size());
        assertEquals(24, e.state().waste.size());
        assertTrue(e.drawOrRecycle());
        assertEquals(24, e.state().stock.size());
        assertEquals(0, e.state().waste.size());
        assertEquals(firstTop, e.state().stock.get(e.state().stock.size() - 1).id());
        assertTrue(e.state().hasExactly52UniqueCards());
    }

    @Test public void illegalMoveDoesNotChangeState() {
        GameEngine e = new GameEngine(55L);
        String before = e.currentEncoded();
        assertFalse(e.moveTableauToTableau(0, 0, 0));
        assertEquals(before, e.currentEncoded());
    }

    @Test public void undoRestoresExactState() {
        GameEngine e = new GameEngine(66L);
        String before = e.currentEncoded();
        assertTrue(e.drawOrRecycle());
        assertNotEquals(before, e.currentEncoded());
        assertTrue(e.undo());
        assertEquals(before, e.currentEncoded());
    }

    @Test public void restartRestoresOriginalDeal() {
        GameEngine e = new GameEngine(77L);
        String original = e.originalDeal();
        e.drawOrRecycle(); e.drawOrRecycle();
        e.restart();
        assertEquals(original, e.currentEncoded());
    }

    @Test public void saveRestoreRoundTripIsExact() {
        GameEngine e = new GameEngine(88L);
        e.drawOrRecycle(); e.drawOrRecycle();
        e.state().elapsedSeconds = 123;
        String saved = e.currentEncoded();
        GameEngine restored = new GameEngine(1L);
        restored.restore(saved, e.originalDeal());
        assertEquals(saved, restored.currentEncoded());
        assertEquals(123, restored.state().elapsedSeconds);
    }

    @Test public void successfulTableauMoveAutomaticallyExposesCard() {
        GameEngine found = null;
        int fromFound = -1, indexFound = -1, toFound = -1;
        outer:
        for (long seed = 1; seed < 10000; seed++) {
            GameEngine e = new GameEngine(seed);
            for (int from = 1; from < 7; from++) {
                List<Card> p = e.state().tableau.get(from);
                int idx = p.size() - 1;
                if (idx <= 0 || p.get(idx - 1).faceUp) continue;
                for (int to = 0; to < 7; to++) {
                    if (to != from && GameEngine.canPlaceOnTableau(p.get(idx), e.state().tableau.get(to))) {
                        found = e; fromFound = from; indexFound = idx; toFound = to; break outer;
                    }
                }
            }
        }
        assertNotNull("A deterministic seed with an exposing legal move should exist", found);
        assertFalse(found.state().tableau.get(fromFound).get(indexFound - 1).faceUp);
        assertTrue(found.moveTableauToTableau(fromFound, indexFound, toFound));
        assertTrue(found.state().tableau.get(fromFound).get(found.state().tableau.get(fromFound).size() - 1).faceUp);
    }

    @Test public void winRequiresAll52CardsInFoundations() {
        GameEngine e = new GameEngine(99L);
        assertFalse(e.isWon());
        GameState s = e.state();
        s.stock.clear(); s.waste.clear();
        for (List<Card> p : s.tableau) p.clear();
        for (List<Card> p : s.foundations) p.clear();
        for (Suit suit : Suit.values()) for (int rank = 1; rank <= 13; rank++)
            s.foundations.get(suit.ordinal()).add(new Card(suit, rank, true));
        assertTrue(s.hasExactly52UniqueCards());
        e.verify();
        assertTrue(e.isWon());
    }

    @Test public void everyOperationRetainsNoDuplicatesOrMissingCards() {
        GameEngine e = new GameEngine(101L);
        for (int i = 0; i < 80; i++) {
            e.drawOrRecycle();
            assertTrue(e.state().hasExactly52UniqueCards());
            Set<String> ids = new HashSet<>();
            for (Card c : e.state().allCards()) assertTrue(ids.add(c.id()));
        }
    }
    @Test public void saveRestorePreservesUndoHistory() {
        GameEngine e = new GameEngine(2025L);
        e.drawOrRecycle();
        e.drawOrRecycle();
        e.drawOrRecycle();
        String state = e.currentEncoded();
        String history = e.undoHistoryEncoded();
        GameEngine restored = new GameEngine(1L);
        restored.restore(state, e.originalDeal(), history);
        assertEquals(3, restored.undoDepth());
        assertEquals(history, restored.undoHistoryEncoded());
        assertTrue(restored.undo());
        assertTrue(restored.undo());
        assertTrue(restored.undo());
        assertEquals(e.originalDeal(), restored.currentEncoded());
    }

    @Test public void malformedUndoHistoryDoesNotMutateEngine() {
        GameEngine e = new GameEngine(3030L);
        e.drawOrRecycle();
        String state = e.currentEncoded();
        String original = e.originalDeal();
        String history = e.undoHistoryEncoded();
        try {
            e.restore(state, original, history + ".not_base64!");
            fail("Malformed undo history should fail");
        } catch (RuntimeException expected) {
            assertEquals(state, e.currentEncoded());
            assertEquals(original, e.originalDeal());
            assertEquals(history, e.undoHistoryEncoded());
        }
    }

    @Test public void undoHistoryIsCappedAndRestorable() {
        GameEngine e = new GameEngine(4040L);
        for (int i = 0; i < 150; i++) assertTrue(e.drawOrRecycle());
        assertEquals(100, e.undoDepth());
        GameEngine restored = new GameEngine(1L);
        restored.restore(e.currentEncoded(), e.originalDeal(), e.undoHistoryEncoded());
        int count = 0;
        while (restored.undo()) count++;
        assertEquals(100, count);
    }

}
