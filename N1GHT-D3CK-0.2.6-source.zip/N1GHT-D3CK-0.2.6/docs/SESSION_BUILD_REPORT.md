# N1GHT D3CK 0.2.5 — Session Build Report

## Result

**Gameplay and persistence reliability pass completed and locally validated. Official APK assembly was not available in the local sandbox.**

Expected GitHub Actions artifact:

```text
N1GHT-D3CK-0.2.5-debug.apk
```

## Completed

- Updated package metadata to version `0.2.5`, code `7`.
- Added persistent undo history with a validated 100-state limit.
- Preserved backward compatibility with older active saves.
- Prevented won deals from remaining in the Continue Game slot.
- Made save restoration transactional and strengthened codec validation.
- Added stock/waste face-orientation invariants.
- Changed GitHub Actions so unit tests must pass before APK delivery.
- Preserved the 0.2.4 UI polish and selected Logo B branding.

## Local evidence

- `docs/engine-self-test-0.2.5.log` — 49 checks
- `docs/gameplay-persistence-audit-0.2.5.log` — 520,820 checks
- `docs/persistence-store-self-test-0.2.5.log` — 21 checks
- `docs/source-validation-0.2.5.log` — source, metadata, workflow, and lifecycle checks
- `docs/android-stub-compilation-0.2.5.log`
- `docs/ui-layout-audit-0.2.5.log` — five viewport profiles
- `docs/0.2.5-GAMEPLAY-PERSISTENCE.md`

## Remaining validation

- Build through Android Gradle Plugin on GitHub Actions.
- Install the resulting APK on the target phone.
- Confirm undo still works after force-close/relaunch.
- Complete several real deals and confirm win statistics and Continue Game cleanup.
- Confirm sound, haptics, reduced motion, and high contrast persist after relaunch.
