# N1GHT D3CK 0.2.6

**Solitaire After Dark** — a native Android Klondike game from CESRB Labs.

## Identity

- Application ID: `com.cesrblabs.nightdeck`
- Version: `0.2.6` (`versionCode 8`)
- Minimum SDK: 26
- Target / compile SDK: 36
- Orientation: portrait
- Network, ads, analytics, accounts, and unnecessary permissions: none

## 0.2.6 clean identity pass

- Removed all gift and Echo-specific wording from the runtime UI.
- Kept the selected N1GHT D3CK wordmark and the angular launcher mark.
- Added build-time guards so the 0.2.6 workflow cannot silently compile an older ZIP.
- About now presents only the game identity, offline/privacy status, and exact version.

## 0.2.5 gameplay and persistence pass

- Persisted the complete undo history across app pause, close, and resume.
- Kept backward compatibility with pre-0.2.5 saves that have no undo-history field.
- Prevented completed deals from reappearing under Continue Game.
- Records a win and removes the completed active save in one preference transaction.
- Made restore transactional: all current/original/undo states validate before the live engine changes.
- Hardened save decoding against malformed metadata, negative counters, invalid cards, and invalid face markers.
- Added stock/waste orientation invariants.
- Reset double-tap tracking after non-card actions so quick stock/menu taps cannot trigger stale auto-moves.
- Improved card-selection switching within a tableau column and between foundation piles.
- Added explicit move-path coverage and large deterministic randomized audits.
- Kept the polished 0.2.4 UI and selected Logo B branding unchanged.

## Game features

- Standard 52-card draw-one Klondike deal
- Seven tableau columns, stock, waste, and four suited foundations
- Alternating-color descending tableau rules
- King-only empty columns
- Sequence movement and automatic exposed-card flip
- Tap-to-select / tap-to-destination controls
- Double-tap to foundation
- Exact-deal restart, persistent undo, hint, move counter, and timer
- Automatic local save/resume using SharedPreferences
- Local statistics: started, won, percentage, streaks, fastest win, fewest moves
- Optional sound, haptics, reduced motion, and high contrast
- Offline operation with no ads, tracking, account, or network permission

## Build

Use JDK 17 and Android SDK Platform 36 / Build Tools 36.0.0.

```bash
chmod +x gradlew
./gradlew --no-daemon clean test assembleDebug
```

The debug APK is produced at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The included GitHub Actions workflow selects the newest `N1GHT-D3CK-*-source.zip` in the repository root, restores the official Gradle wrapper, requires unit tests to pass, builds and validates the APK, and uploads the versioned artifact.

## Independent checks

```bash
mkdir -p build/selftest
javac --release 17 -d build/selftest \
  app/src/main/java/com/cesrblabs/nightdeck/engine/*.java \
  tools/EngineSelfTest.java \
  tools/GameplayPersistenceAudit.java
java -cp build/selftest EngineSelfTest
java -cp build/selftest GameplayPersistenceAudit
python3 tools/ui_layout_audit.py
```

`tools/PersistenceStoreSelfTest.java` additionally validates settings, active saves, corrupt-save cleanup, completed-save removal, and statistics using an in-memory SharedPreferences implementation.

## Validation status

The engine, Android-facing Java source, XML resources, version metadata, undo persistence, completed-game lifecycle, codec defenses, statistics behavior, and five portrait viewport profiles were validated locally. Official Android Gradle Plugin assembly and physical-device rendering remain separate GitHub Actions / device checks.
