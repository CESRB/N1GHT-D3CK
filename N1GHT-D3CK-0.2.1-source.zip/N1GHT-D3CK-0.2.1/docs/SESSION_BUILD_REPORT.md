# N1GHT D3CK 0.2.1 — Crash Repair and Validation Report

**Status: source repaired and locally validated**  
**Android APK assembly: run the included GitHub Actions workflow**  
**Runtime confirmation required: install the 0.2.1 artifact on the target device**

## Runtime defect received

The Android 17 physical-device log showed repeatable immediate launch crashes:

```text
java.lang.NullPointerException: Attempt to invoke virtual method
'void android.graphics.RectF.set(float, float, float, float)' on a null object reference
    at com.cesrblabs.nightdeck.NightDeckView.computeLayout(NightDeckView.java:239)
    at com.cesrblabs.nightdeck.NightDeckView.onSizeChanged(NightDeckView.java:201)
```

## Root cause

Six `RectF[]` containers were created, but their entries were never initialized. Android called `onSizeChanged()` during the first frame, and `computeLayout()` attempted to call `set(...)` on `tableauRects[0]`, which was null. The same latent defect affected action, foundation, settings, statistics, and pause-menu rectangles.

## Repair

- Added `createRectArray(int)` to allocate every array element.
- Initialized all six rectangle arrays through that helper.
- Advanced version to `0.2.1` / `versionCode 3`.
- Updated workflow artifact names to `0.2.1`.
- Preserved the home screen, Echo dedication, redesigned cards, solitaire engine, package identity, and offline/privacy behavior.

## Validation executed

- First-layout smoke test at 1080 × 2424: **passed without exception**
- Array initialization check: **28/28 RectF entries non-null**
- Pure Java game engine: **49 checks passed**
- Android-facing Java compilation against local API-shaped stubs: **passed**
- Android XML parsing: **14 files passed**
- Application ID retained: `com.cesrblabs.nightdeck`
- Version: `0.2.1` (`versionCode 3`)

## Not yet claimed

This environment did not run Android Gradle Plugin, AAPT2, DEX, signing, APK installation, or post-fix physical-device launch. The included GitHub Actions workflow performs the genuine Android build and package validation.
