# N1GHT D3CK 0.2.1

**Solitaire After Dark** — a private, native Android Klondike solitaire game from CESRB Labs, rebuilt as a gift for Echo.

## Identity

- Application ID: `com.cesrblabs.nightdeck`
- Version: `0.2.1` (`versionCode 2`)
- Minimum SDK: 26
- Target / compile SDK: 36
- Orientation: portrait
- Network, ads, analytics, accounts, and unnecessary permissions: none

## 0.2.1 gift-quality redesign

- Proper home screen instead of launching directly into a deal
- Continue Game and New Deal flows
- Dedicated Statistics, Settings, How to Play, About, and victory screens
- Personal `Made for Echo` presentation and dedication
- Correct system-bar inset handling for modern edge-to-edge Android
- Responsive seven-column board layout
- Compact game header, move/time metrics, and bottom action bar
- Rebuilt playing cards with corner indices, pip layouts, custom court-card art, shadows, and selectable high contrast
- Rebuilt cyber-bunny card back and adaptive launcher icon
- Custom pause menu and new/restart confirmations
- Refined win presentation with game summary
- Reduced-motion setting for calmer backgrounds and celebrations

## Game features retained

- Standard 52-card draw-one Klondike deal
- Seven tableau columns, stock, waste, and four suited foundations
- Alternating-color descending tableau rules
- King-only empty columns
- Sequence movement and automatic exposed-card flip
- Tap-to-select / tap-to-destination controls
- Double-tap to foundation
- Exact-deal restart, undo, hint, move counter, and timer
- Automatic local save/resume using SharedPreferences
- Local statistics: started, won, percentage, streaks, fastest win, fewest moves
- Optional sound and haptics

## Build

Use JDK 17 and Android SDK Platform 36 / Build Tools 36.0.0.

```bash
chmod +x gradlew
./gradlew --no-daemon assembleDebug
```

The debug APK is produced at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The included GitHub Actions workflow can restore the missing official Gradle wrapper JAR, install SDK 36, build the APK, validate it, and upload `N1GHT-D3CK-0.2.1-debug` as an artifact.

## Independent engine check

```bash
mkdir -p build/selftest
javac -d build/selftest app/src/main/java/com/cesrblabs/nightdeck/engine/*.java tools/EngineSelfTest.java
java -cp build/selftest EngineSelfTest
```

## Validation status

The pure Java engine and source structure can be validated without Android tooling. APK compilation and physical-device behavior must be reported separately and honestly.

## 0.2.1 launch-crash repair

Physical-device logcat from Android 17 identified an immediate `NullPointerException` in `NightDeckView.computeLayout()`. The rectangle arrays had been allocated without allocating their individual `RectF` elements. Version 0.2.1 initializes all 28 array-backed rectangles before the first Android layout pass. A local API-stub smoke test now invokes the first 1080 × 2424 layout and verifies every rectangle element is non-null.
