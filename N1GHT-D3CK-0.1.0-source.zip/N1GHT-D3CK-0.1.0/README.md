# N1GHT D3CK 0.1.0

**Solitaire After Dark** — a native Android Klondike solitaire game developed by CESRB Labs.

## Identity

- Application ID: `com.cesrblabs.nightdeck`
- Version: `0.1.0` (`versionCode 1`)
- Minimum SDK: 26
- Target / compile SDK: 36
- Orientation: portrait
- Network, ads, analytics, accounts, and permissions: none

## Implemented 0.1.0 scope

- Standard 52-card draw-one Klondike deal
- Seven tableau columns, stock, waste, and four suited foundations
- Alternating-color descending tableau rules
- King-only empty columns
- Sequence movement and automatic exposed-card flip
- Tap-to-select / tap-to-destination controls
- Double-tap to foundation
- New game, exact-deal restart, undo, hint, move counter, timer, win dialog
- Automatic local save/resume using SharedPreferences
- Local statistics: started, won, percentage, streaks, fastest win, fewest moves
- Sound, haptics, and reduced-motion settings
- Original cyber-bunny card back and launcher icon
- No internet permission or third-party runtime libraries

## Build

Use JDK 17 and Android SDK Platform 36 / Build Tools 36.0.0.

```bash
chmod +x gradlew
./gradlew --no-daemon clean test lint assembleDebug
```

The debug APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.

## Independent engine check

The pure Java rules engine can be checked without Android tooling:

```bash
mkdir -p build/selftest
javac -d build/selftest app/src/main/java/com/cesrblabs/nightdeck/engine/*.java tools/EngineSelfTest.java
java -cp build/selftest EngineSelfTest
```

## Runtime status

Source-level engine checks are separate from Android package compilation and physical-device testing. Do not describe a build as runtime-tested until the APK has actually been installed and launched.
