# Build notes

Portable source is configured for Android Gradle Plugin 8.10.1, Gradle 8.11.1, Java 17 bytecode, compile/target SDK 36, and minimum SDK 26.

The checked-in repository configuration uses only Google Maven, Maven Central, and Gradle Plugin Portal. Machine-specific SDK paths, caches, credentials, signing secrets, and downloaded toolchains are excluded.

The debug build uses Android's normal debug signing configuration. Production signing is intentionally outside 0.1.0.

## Current-session wrapper boundary

The checked-in wrapper scripts and `gradle-wrapper.properties` are present, but `gradle-wrapper.jar` could not be acquired in this session. It was not fabricated. The included GitHub Actions workflow provisions Gradle 8.11.1 and invokes the official `gradle wrapper` task before running `clean test lint assembleDebug`.
