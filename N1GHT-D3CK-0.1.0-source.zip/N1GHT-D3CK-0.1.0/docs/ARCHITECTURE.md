# Architecture

`engine/` is pure Java and owns cards, deal generation, legal moves, invariant verification, undo snapshots, restart, deterministic seeded shuffles, hints, win detection, and save-state encoding. It has no Android dependency.

`NightDeckView` is a native Android custom View. It renders the board and original CESRB-inspired card treatment with Canvas primitives. Tap controls remain the primary interaction. Android platform behavior—dialogs, tones, haptics, and lifecycle persistence—stays outside the rules engine.

`StatsStore` uses app-private SharedPreferences for game state, settings, and statistics. No cloud service, account, external storage, analytics SDK, network client, or permission is used.
