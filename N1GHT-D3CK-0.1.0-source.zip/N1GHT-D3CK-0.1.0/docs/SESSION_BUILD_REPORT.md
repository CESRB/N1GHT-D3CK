# N1GHT D3CK 0.1.0 — Build Report

**Status: Source created but APK build failed**  
**Build blocked by unavailable external dependency**  
**APK not runtime-tested**

## Requested artifact status

- `N1GHT-D3CK-0.1.0-debug.apk`: **not generated**
- `N1GHT-D3CK-0.1.0-source.zip`: generated
- `N1GHT-D3CK-0.1.0-checksums.txt`: generated
- Android package validation/signing/alignment: not executed because no APK exists
- Runtime installation/launch/gameplay testing: not executed

## Project identity

- Application label: N1GHT D3CK
- Subtitle: Solitaire After Dark
- Developer credit: CESRB Labs
- Application ID: `com.cesrblabs.nightdeck`
- Version: `0.1.0` (`versionCode 1`)
- Minimum SDK: 26
- Target/compile SDK: 36
- Orientation: portrait
- Permissions declared: none
- Architecture: native Java Android application with a custom Android `View` and a separated pure-Java Klondike engine

## Exact official build command attempted

```text
./gradlew --no-daemon clean test lint assembleDebug --stacktrace
```

Exit code: `1`

Exact relevant output:

```text
Error: Could not find or load main class org.gradle.wrapper.GradleWrapperMain
Caused by: java.lang.ClassNotFoundException: org.gradle.wrapper.GradleWrapperMain
gradlew exit code: 1
```

The standard `gradle-wrapper.jar` could not be acquired. It was not replaced with a fabricated wrapper or a hand-packed APK.

## Build environment inspected

- Host: Debian GNU/Linux 13
- Java runtime/compiler: OpenJDK 21.0.10
- Project Java source/bytecode target: 17
- System Gradle: not installed (`gradle: command not found`, exit 127)
- Android SDK / `sdkmanager`: not installed
- Android packaging tools: `aapt2`, `apksigner`, and `zipalign` not installed
- ADB/emulator/device: unavailable
- Local Gradle, Maven, Android SDK, build-tool, and wrapper caches: no usable toolchain found

## Repair and fallback work attempted

1. Created a clean native Android Studio-compatible project and kept Android/UI code separate from the pure-Java rules engine.
2. Implemented the Klondike engine, custom board UI, tap/double-tap controls, new/restart/undo/hint, autosave/resume, settings, win flow, and local statistics.
3. Found and repaired a real save-state codec section-count defect during executable engine validation.
4. Recompiled the pure-Java engine with `javac --release 17` and ran the independent engine self-test: **49 checks passed**.
5. Added a 15-test JUnit source suite covering deal integrity, tableau/foundation rules, sequence movement, stock/recycle, undo, restart, save/restore, auto-exposure, win detection, and card uniqueness. **Test not executed through Gradle** because Gradle and its dependency environment were unavailable.
6. Parsed all Android XML resources and manifest files successfully and ran 16 source/static project checks.
7. Searched local filesystem roots for Gradle distributions, wrapper JARs, Android SDK platforms, `android.jar`, `aapt2`, `apksigner`, and `zipalign`; none were found.
8. Attempted the public Gradle distribution route. `curl` failed with: `Could not resolve host: services.gradle.org` (exit 6).
9. Attempted the authenticated internal Artifactory system and Gradle registry routes. Both returned **HTTP 503 Service Temporarily Unavailable**.
10. Attempted Debian package repository refresh. Repositories repeatedly failed to connect and the operation timed out; no package indexes or Gradle/Android packages became available.
11. Checked SDKMAN, GitHub CLI, Docker, Podman, and Skopeo routes; the required tools were not installed.
12. Created `.github/workflows/android-build.yml` using JDK 17, Android SDK 36, Gradle 8.11.1, the official `gradle wrapper` task, `clean test lint assembleDebug`, and APK/report artifact upload. The workflow could not be dispatched because this session has no GitHub repository connector, authenticated GitHub CLI, or repository target.

## Validation results that did run

- Independent pure-Java engine compilation: passed
- Independent engine checks: **49 passed**
- Android XML parsing: **13 files passed**
- Source/static checks: **16 passed**
- Declared Android permissions: none found
- WebView, ad, analytics, account, and network implementation: none found
- ZIP/source hygiene validation: recorded with the delivered source archive

These results validate source and engine behavior only. They are not an Android compile, APK package validation, signing verification, installation test, or runtime test.

## Specific remaining blocker

The session could not obtain or access an official Gradle executable/wrapper JAR, Android SDK platform, Android Build Tools, or a runnable GitHub Actions repository. Therefore Android Gradle Plugin could not start and `assembleDebug` could not generate an APK. Hand-packing or fabricating an APK was intentionally not used.

## Evidence files

- `N1GHT-D3CK-0.1.0-build-attempt.log`
- `N1GHT-D3CK-0.1.0-fallback-attempts.log`
- `docs/engine-self-test.log` inside the source archive
- `docs/source-validation.log` inside the source archive
