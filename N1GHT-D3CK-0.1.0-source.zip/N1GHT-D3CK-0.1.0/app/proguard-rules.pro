# No shrinking rules are required for the 0.1.0 testing build.
