package com.cesrblabs.nightdeck;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import com.cesrblabs.nightdeck.engine.Card;
import com.cesrblabs.nightdeck.engine.GameEngine;
import com.cesrblabs.nightdeck.engine.GameState;
import com.cesrblabs.nightdeck.engine.Suit;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class NightDeckView extends View {
    private static final int BLACK = Color.rgb(9, 7, 13);
    private static final int CHARCOAL = Color.rgb(23, 18, 31);
    private static final int PURPLE = Color.rgb(91, 42, 134);
    private static final int PINK = Color.rgb(255, 61, 174);
    private static final int SOFT_PINK = Color.rgb(255, 158, 215);
    private static final int CARD_WHITE = Color.rgb(244, 239, 247);
    private static final int CARD_BLACK = Color.rgb(28, 24, 33);
    private static final int CARD_RED = Color.rgb(184, 28, 91);

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final StatsStore store;
    private final GameEngine engine;
    private final ToneGenerator tones = new ToneGenerator(AudioManager.STREAM_MUSIC, 30);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final RectF[] actionRects = new RectF[5];
    private final RectF stockRect = new RectF(), wasteRect = new RectF();
    private final RectF[] foundationRects = new RectF[4];
    private final RectF[] tableauRects = new RectF[7];
    private final RectF settingsPanel = new RectF();
    private final RectF[] settingRows = new RectF[4];
    private float density, cardW, cardH, gap, topY, tableauY, downStep, upStep;
    private String message = "Tap stock to draw • tap cards to select";
    private boolean settingsOpen;
    private long lastTapTime;
    private String lastTapKey = "";

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!engine.isWon()) engine.state().elapsedSeconds++;
            invalidate();
            handler.postDelayed(this, 1000);
        }
    };

    public NightDeckView(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        store = new StatsStore(context);
        engine = new GameEngine(System.currentTimeMillis());
        if (!store.loadGame(engine)) store.gameStarted();
        setBackgroundColor(BLACK);
        setFocusable(true);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1.5f));
        handler.postDelayed(ticker, 1000);
    }

    public void persist() { store.saveGame(engine); }

    @Override protected void onDetachedFromWindow() {
        handler.removeCallbacks(ticker);
        tones.release();
        persist();
        super.onDetachedFromWindow();
    }

    private float dp(float value) { return value * density; }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        gap = dp(5);
        float side = dp(10);
        cardW = (w - side * 2 - gap * 6) / 7f;
        cardH = cardW * 1.42f;
        downStep = Math.max(dp(13), cardH * 0.15f);
        upStep = Math.max(dp(25), cardH * 0.29f);
        topY = dp(143);
        tableauY = topY + cardH + dp(25);
        for (int i = 0; i < 5; i++) actionRects[i] = new RectF(side + i * ((w - side * 2 + gap) / 5f), dp(72), side + (i + 1) * ((w - side * 2 + gap) / 5f) - gap, dp(112));
        stockRect.set(side, topY, side + cardW, topY + cardH);
        wasteRect.set(side + cardW + gap, topY, side + cardW * 2 + gap, topY + cardH);
        for (int i = 0; i < 4; i++) {
            float left = w - side - cardW * (4 - i) - gap * (3 - i);
            foundationRects[i] = new RectF(left, topY, left + cardW, topY + cardH);
        }
        for (int i = 0; i < 7; i++) {
            float left = side + i * (cardW + gap);
            tableauRects[i] = new RectF(left, tableauY, left + cardW, h - dp(12));
        }
        settingsPanel.set(dp(24), dp(120), w - dp(24), h - dp(36));
        for (int i = 0; i < 4; i++) settingRows[i] = new RectF(settingsPanel.left + dp(18), settingsPanel.top + dp(90) + i * dp(58), settingsPanel.right - dp(18), settingsPanel.top + dp(136) + i * dp(58));
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawBackground(canvas);
        drawHeader(canvas);
        drawPiles(canvas);
        drawTableau(canvas);
        if (settingsOpen) drawSettings(canvas);
    }

    private void drawBackground(Canvas c) {
        c.drawColor(BLACK);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.argb(28, 142, 68, 200));
        for (float x = 0; x < getWidth(); x += dp(36)) c.drawLine(x, 0, x, getHeight(), paint);
        for (float y = dp(125); y < getHeight(); y += dp(36)) c.drawLine(0, y, getWidth(), y, paint);
        paint.setColor(Color.argb(38, 255, 61, 174));
        for (int i = 0; i < 9; i++) {
            float y = dp(130 + i * 137);
            c.drawRect((i % 2 == 0 ? 0 : getWidth() - dp(44)), y, (i % 2 == 0 ? dp(32) : getWidth()), y + dp(2), paint);
        }
    }

    private void drawHeader(Canvas c) {
        paint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
        paint.setTextSize(dp(25)); paint.setColor(CARD_WHITE);
        c.drawText("N1GHT D3CK", dp(12), dp(31), paint);
        paint.setTextSize(dp(10)); paint.setColor(SOFT_PINK);
        c.drawText("SOLITAIRE AFTER DARK  //  CESRB LABS", dp(13), dp(47), paint);
        paint.setTextAlign(Paint.Align.RIGHT); paint.setTextSize(dp(12)); paint.setColor(CARD_WHITE);
        c.drawText(String.format(Locale.US, "%d MOVES   %s", engine.state().moves, formatTime(engine.state().elapsedSeconds)), getWidth() - dp(12), dp(31), paint);
        paint.setTextAlign(Paint.Align.LEFT);
        String[] labels = {"NEW", "RESTART", "UNDO", "HINT", "SETTINGS"};
        for (int i = 0; i < actionRects.length; i++) drawButton(c, actionRects[i], labels[i], i == 2 && !engine.canUndo());
        paint.setTextSize(dp(10)); paint.setColor(Color.rgb(204, 191, 215));
        c.drawText(message, dp(12), dp(130), paint);
    }

    private void drawButton(Canvas c, RectF r, String label, boolean disabled) {
        paint.setStyle(Paint.Style.FILL); paint.setColor(disabled ? Color.rgb(31, 26, 39) : CHARCOAL); c.drawRoundRect(r, dp(8), dp(8), paint);
        stroke.setColor(disabled ? Color.rgb(55, 48, 63) : PURPLE); c.drawRoundRect(r, dp(8), dp(8), stroke);
        paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(dp(10)); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); paint.setColor(disabled ? Color.DKGRAY : SOFT_PINK);
        c.drawText(label, r.centerX(), r.centerY() + dp(4), paint); paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawPiles(Canvas c) {
        drawEmptySlot(c, stockRect, engine.state().stock.isEmpty() ? "↻" : "");
        if (!engine.state().stock.isEmpty()) drawCardBack(c, stockRect, false);
        if (engine.state().waste.isEmpty()) drawEmptySlot(c, wasteRect, "W"); else drawFaceCard(c, engine.state().waste.get(engine.state().waste.size() - 1), wasteRect, selected(GameEngine.SourceType.WASTE, 0, engine.state().waste.size() - 1));
        for (int i = 0; i < 4; i++) {
            List<Card> f = engine.state().foundations.get(i);
            if (f.isEmpty()) drawEmptySlot(c, foundationRects[i], Suit.values()[i].symbol);
            else drawFaceCard(c, f.get(f.size() - 1), foundationRects[i], selected(GameEngine.SourceType.FOUNDATION, i, f.size() - 1));
        }
    }

    private void drawTableau(Canvas c) {
        for (int col = 0; col < 7; col++) {
            List<Card> pile = engine.state().tableau.get(col);
            if (pile.isEmpty()) drawEmptySlot(c, new RectF(tableauRects[col].left, tableauY, tableauRects[col].right, tableauY + cardH), "K");
            float y = tableauY;
            for (int i = 0; i < pile.size(); i++) {
                Card card = pile.get(i);
                RectF r = new RectF(tableauRects[col].left, y, tableauRects[col].right, y + cardH);
                if (card.faceUp) drawFaceCard(c, card, r, selected(GameEngine.SourceType.TABLEAU, col, i)); else drawCardBack(c, r, false);
                y += card.faceUp ? upStep : downStep;
            }
        }
    }

    private boolean selected(GameEngine.SourceType type, int pile, int index) {
        return engine.selection.type == type && engine.selection.pile == pile && engine.selection.index == index;
    }

    private void drawEmptySlot(Canvas c, RectF r, String text) {
        paint.setColor(Color.argb(110, 24, 17, 31)); paint.setStyle(Paint.Style.FILL); c.drawRoundRect(r, dp(8), dp(8), paint);
        stroke.setColor(Color.argb(150, 112, 57, 143)); stroke.setStrokeWidth(dp(1.2f)); c.drawRoundRect(r, dp(8), dp(8), stroke);
        paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(dp(24)); paint.setColor(Color.argb(100, 255, 158, 215)); c.drawText(text, r.centerX(), r.centerY() + dp(8), paint); paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawFaceCard(Canvas c, Card card, RectF r, boolean selected) {
        paint.setColor(CARD_WHITE); paint.setStyle(Paint.Style.FILL); c.drawRoundRect(r, dp(7), dp(7), paint);
        stroke.setStrokeWidth(selected ? dp(4) : dp(1.2f)); stroke.setColor(selected ? PINK : Color.rgb(78, 67, 85)); c.drawRoundRect(r, dp(7), dp(7), stroke);
        int ink = card.suit.red ? CARD_RED : CARD_BLACK;
        paint.setColor(ink); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); paint.setTextSize(Math.max(dp(14), cardW * .22f));
        c.drawText(rankText(card.rank), r.left + dp(5), r.top + dp(18), paint);
        paint.setTextSize(Math.max(dp(14), cardW * .24f)); c.drawText(card.suit.symbol, r.left + dp(5), r.top + dp(37), paint);
        paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(Math.max(dp(22), cardW * .40f));
        c.drawText(card.suit.symbol, r.centerX(), r.centerY() + dp(10), paint); paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawCardBack(Canvas c, RectF r, boolean selected) {
        paint.setColor(CHARCOAL); paint.setStyle(Paint.Style.FILL); c.drawRoundRect(r, dp(7), dp(7), paint);
        stroke.setStrokeWidth(selected ? dp(4) : dp(2)); stroke.setColor(selected ? SOFT_PINK : PINK); c.drawRoundRect(r, dp(7), dp(7), stroke);
        RectF inner = new RectF(r.left + dp(5), r.top + dp(5), r.right - dp(5), r.bottom - dp(5)); stroke.setColor(PURPLE); stroke.setStrokeWidth(dp(1)); c.drawRoundRect(inner, dp(5), dp(5), stroke);
        Path bunny = new Path();
        bunny.moveTo(r.centerX(), r.top + cardH * .36f);
        bunny.cubicTo(r.left + cardW * .27f, r.top + cardH * .18f, r.left + cardW * .22f, r.top + cardH * .58f, r.centerX(), r.top + cardH * .73f);
        bunny.cubicTo(r.right - cardW * .22f, r.top + cardH * .58f, r.right - cardW * .27f, r.top + cardH * .18f, r.centerX(), r.top + cardH * .36f);
        stroke.setColor(PINK); stroke.setStrokeWidth(dp(2)); c.drawPath(bunny, stroke);
        paint.setColor(SOFT_PINK); c.drawCircle(r.left + cardW * .42f, r.top + cardH * .52f, dp(2), paint); c.drawCircle(r.right - cardW * .42f, r.top + cardH * .52f, dp(2), paint);
        for (int i = 0; i < 3; i++) c.drawRect(r.centerX() - dp(9) + i * dp(7), r.top + cardH * .64f, r.centerX() - dp(5) + i * dp(7), r.top + cardH * .68f, paint);
    }

    private String rankText(int rank) { return rank == 1 ? "A" : rank == 11 ? "J" : rank == 12 ? "Q" : rank == 13 ? "K" : Integer.toString(rank); }
    private String formatTime(long seconds) { return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60); }

    private void drawSettings(Canvas c) {
        paint.setColor(Color.argb(235, 9, 7, 13)); c.drawRoundRect(settingsPanel, dp(14), dp(14), paint);
        stroke.setColor(PINK); stroke.setStrokeWidth(dp(2)); c.drawRoundRect(settingsPanel, dp(14), dp(14), stroke);
        paint.setTextSize(dp(24)); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); paint.setColor(CARD_WHITE); c.drawText("SETTINGS // STATS", settingsPanel.left + dp(18), settingsPanel.top + dp(38), paint);
        paint.setTextSize(dp(11)); paint.setColor(SOFT_PINK); c.drawText("Local only • no account • no analytics", settingsPanel.left + dp(18), settingsPanel.top + dp(60), paint);
        drawSettingRow(c, settingRows[0], "SOUND", store.sound());
        drawSettingRow(c, settingRows[1], "HAPTICS", store.haptic());
        drawSettingRow(c, settingRows[2], "REDUCED MOTION", store.reducedMotion());
        drawSettingRow(c, settingRows[3], "CLOSE", true);
        float y = settingRows[3].bottom + dp(45);
        paint.setColor(CARD_WHITE); paint.setTextSize(dp(14));
        c.drawText("Games started", settingsPanel.left + dp(20), y, paint); c.drawText(Integer.toString(store.gamesStarted()), settingsPanel.centerX(), y, paint);
        c.drawText("Games won", settingsPanel.left + dp(20), y + dp(28), paint); c.drawText(Integer.toString(store.gamesWon()), settingsPanel.centerX(), y + dp(28), paint);
        c.drawText("Win percentage", settingsPanel.left + dp(20), y + dp(56), paint); c.drawText(store.winPercent() + "%", settingsPanel.centerX(), y + dp(56), paint);
        c.drawText("Current / best streak", settingsPanel.left + dp(20), y + dp(84), paint); c.drawText(store.currentStreak() + " / " + store.bestStreak(), settingsPanel.centerX(), y + dp(84), paint);
        c.drawText("Fastest win", settingsPanel.left + dp(20), y + dp(112), paint); c.drawText(store.fastestWin() == 0 ? "—" : formatTime(store.fastestWin()), settingsPanel.centerX(), y + dp(112), paint);
        c.drawText("Fewest moves", settingsPanel.left + dp(20), y + dp(140), paint); c.drawText(store.fewestMoves() == 0 ? "—" : Integer.toString(store.fewestMoves()), settingsPanel.centerX(), y + dp(140), paint);
        paint.setTextSize(dp(10)); paint.setColor(Color.rgb(179, 164, 190)); c.drawText("N1GHT D3CK 0.1.0 • Developed by CESRB Labs", settingsPanel.left + dp(20), settingsPanel.bottom - dp(24), paint);
    }

    private void drawSettingRow(Canvas c, RectF r, String label, boolean active) {
        paint.setColor(CHARCOAL); c.drawRoundRect(r, dp(8), dp(8), paint); stroke.setColor(active ? PURPLE : Color.DKGRAY); stroke.setStrokeWidth(dp(1.5f)); c.drawRoundRect(r, dp(8), dp(8), stroke);
        paint.setColor(CARD_WHITE); paint.setTextSize(dp(13)); paint.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); c.drawText(label, r.left + dp(14), r.centerY() + dp(5), paint);
        if (!"CLOSE".equals(label)) { paint.setTextAlign(Paint.Align.RIGHT); paint.setColor(active ? PINK : Color.GRAY); c.drawText(active ? "ON" : "OFF", r.right - dp(14), r.centerY() + dp(5), paint); paint.setTextAlign(Paint.Align.LEFT); }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP) return true;
        float x = event.getX(), y = event.getY();
        if (settingsOpen) return handleSettingsTap(x, y);
        for (int i = 0; i < actionRects.length; i++) if (actionRects[i].contains(x, y)) { handleAction(i); return true; }
        if (stockRect.contains(x, y)) { if (engine.drawOrRecycle()) moved("Stock advanced", 0); else invalid("Nothing to draw"); return true; }
        if (wasteRect.contains(x, y)) { handleWasteTap(isDouble("waste")); return true; }
        for (int i = 0; i < 4; i++) if (foundationRects[i].contains(x, y)) { handleFoundationTap(i, isDouble("foundation" + i)); return true; }
        for (int col = 0; col < 7; col++) if (tableauRects[col].contains(x, y)) { handleTableauTap(col, y, isDouble("tableau" + col + ":" + tableauIndexAt(col, y))); return true; }
        engine.selection.clear(); message = "Selection cleared"; invalidate(); return true;
    }

    private boolean isDouble(String key) {
        long now = SystemClock.uptimeMillis();
        boolean result = key.equals(lastTapKey) && now - lastTapTime < 350;
        lastTapKey = key; lastTapTime = now; return result;
    }

    private void handleAction(int action) {
        if (action == 0) confirmAbandon("Start a new shuffled game?", this::startNewGame);
        else if (action == 1) confirmAbandon("Restart this exact deal?", () -> { engine.restart(); message = "Deal restarted"; persist(); invalidate(); });
        else if (action == 2) { if (engine.undo()) { message = "Move undone"; sound(3); persist(); } else invalid("Nothing to undo"); invalidate(); }
        else if (action == 3) { message = engine.hint(); sound(1); invalidate(); }
        else { settingsOpen = true; invalidate(); }
    }

    private void confirmAbandon(String text, Runnable yes) {
        if (engine.state().moves == 0 || engine.isWon()) { yes.run(); return; }
        new AlertDialog.Builder(getContext()).setTitle("Abandon active game?").setMessage(text)
                .setNegativeButton("Cancel", null).setPositiveButton("Continue", (d, w) -> yes.run()).show();
    }

    private void startNewGame() {
        if (!engine.isWon() && engine.state().moves > 0) store.gameAbandoned();
        engine.newGame(System.currentTimeMillis()); store.gameStarted(); message = "New deck shuffled"; sound(5); persist(); invalidate();
    }

    private void handleWasteTap(boolean dbl) {
        if (engine.state().waste.isEmpty()) { invalid("Waste is empty"); return; }
        if (dbl && engine.moveWasteToFoundation()) { moved("Moved to foundation", 4); return; }
        if (engine.selection.type == GameEngine.SourceType.WASTE) { engine.selection.clear(); message = "Selection cleared"; }
        else { engine.selectWaste(); message = "Selected " + engine.state().waste.get(engine.state().waste.size() - 1).label(); sound(1); }
        invalidate();
    }

    private void handleFoundationTap(int foundation, boolean dbl) {
        if (!engine.selection.isNone()) {
            if (engine.moveSelectionToFoundation(foundation)) moved("Foundation move", 4); else invalid("That card cannot go there");
            return;
        }
        if (!engine.state().foundations.get(foundation).isEmpty()) { engine.selectFoundation(foundation); message = "Foundation card selected"; sound(1); }
        else invalid("Foundation needs an Ace");
        invalidate();
    }

    private int tableauIndexAt(int col, float tapY) {
        List<Card> pile = engine.state().tableau.get(col);
        if (pile.isEmpty()) return -1;
        float y = tableauY;
        for (int i = 0; i < pile.size(); i++) {
            float step = pile.get(i).faceUp ? upStep : downStep;
            boolean last = i == pile.size() - 1;
            if (tapY >= y && tapY < (last ? y + cardH : y + step)) return i;
            y += step;
        }
        return pile.size() - 1;
    }

    private void handleTableauTap(int col, float tapY, boolean dbl) {
        int index = tableauIndexAt(col, tapY);
        List<Card> pile = engine.state().tableau.get(col);
        if (dbl && index == pile.size() - 1 && index >= 0 && pile.get(index).faceUp && engine.moveTableauToFoundation(col)) { moved("Moved to foundation", 4); return; }
        if (!engine.selection.isNone()) {
            if (engine.selection.type == GameEngine.SourceType.TABLEAU && engine.selection.pile == col) { engine.selection.clear(); message = "Selection cleared"; invalidate(); return; }
            if (engine.moveSelectionToTableau(col)) moved("Cards moved", 2); else invalid("Illegal tableau move");
            return;
        }
        if (index < 0) { invalid("Only a King can fill this column"); return; }
        Card card = pile.get(index);
        if (!card.faceUp) { invalid("That card is face down"); return; }
        engine.selectTableau(col, index);
        if (engine.selection.isNone()) invalid("Select a correctly ordered sequence"); else { message = "Selected " + card.label(); sound(1); invalidate(); }
    }

    private boolean handleSettingsTap(float x, float y) {
        if (!settingsPanel.contains(x, y)) { settingsOpen = false; invalidate(); return true; }
        if (settingRows[0].contains(x, y)) { store.setSound(!store.sound()); sound(1); }
        else if (settingRows[1].contains(x, y)) { store.setHaptic(!store.haptic()); haptic(); }
        else if (settingRows[2].contains(x, y)) store.setReducedMotion(!store.reducedMotion());
        else if (settingRows[3].contains(x, y)) settingsOpen = false;
        invalidate(); return true;
    }

    private void moved(String text, int tone) {
        message = text; sound(tone); haptic(); persist();
        if (engine.isWon() && !engine.state().wonRecorded) {
            engine.state().wonRecorded = true; store.gameWon(engine.state().elapsedSeconds, engine.state().moves); persist();
            new AlertDialog.Builder(getContext()).setTitle("D3CK CLEARED").setMessage("You won in " + engine.state().moves + " moves • " + formatTime(engine.state().elapsedSeconds))
                    .setNegativeButton("Close", null).setPositiveButton("New game", (d, w) -> startNewGame()).show();
            sound(6);
        }
        invalidate();
    }

    private void invalid(String text) { message = text; sound(2); haptic(); invalidate(); }
    private void haptic() { if (store.haptic()) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); }
    private void sound(int kind) {
        if (!store.sound()) return;
        int tone = kind == 2 ? ToneGenerator.TONE_PROP_NACK : kind == 4 ? ToneGenerator.TONE_PROP_ACK : kind == 5 ? ToneGenerator.TONE_CDMA_PIP : kind == 6 ? ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD : ToneGenerator.TONE_PROP_BEEP;
        tones.startTone(tone, kind == 6 ? 350 : 55);
    }
}
