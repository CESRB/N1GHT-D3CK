package com.cesrblabs.nightdeck;

import android.content.Context;
import android.content.SharedPreferences;
import com.cesrblabs.nightdeck.engine.GameEngine;

public final class StatsStore {
    private final SharedPreferences prefs;
    public StatsStore(Context context) { prefs = context.getSharedPreferences("nightdeck", Context.MODE_PRIVATE); }

    public boolean sound() { return prefs.getBoolean("sound", true); }
    public boolean haptic() { return prefs.getBoolean("haptic", true); }
    public boolean reducedMotion() { return prefs.getBoolean("reduced_motion", false); }
    public void setSound(boolean v) { prefs.edit().putBoolean("sound", v).apply(); }
    public void setHaptic(boolean v) { prefs.edit().putBoolean("haptic", v).apply(); }
    public void setReducedMotion(boolean v) { prefs.edit().putBoolean("reduced_motion", v).apply(); }

    public void saveGame(GameEngine engine) {
        prefs.edit().putString("game", engine.currentEncoded()).putString("original", engine.originalDeal()).apply();
    }
    public boolean hasSavedGame() { return prefs.contains("game") && prefs.contains("original"); }
    public boolean loadGame(GameEngine engine) {
        try {
            String game = prefs.getString("game", null), original = prefs.getString("original", null);
            if (game == null || original == null) return false;
            engine.restore(game, original);
            return true;
        } catch (RuntimeException badSave) {
            prefs.edit().remove("game").remove("original").apply();
            return false;
        }
    }

    public void gameStarted() {
        prefs.edit().putInt("games_started", gamesStarted() + 1).apply();
    }
    public void gameWon(long seconds, int moves) {
        int current = currentStreak() + 1;
        SharedPreferences.Editor e = prefs.edit()
                .putInt("games_won", gamesWon() + 1)
                .putInt("current_streak", current)
                .putInt("best_streak", Math.max(bestStreak(), current));
        long fastest = fastestWin();
        if (fastest == 0 || seconds < fastest) e.putLong("fastest_win", seconds);
        int fewest = fewestMoves();
        if (fewest == 0 || moves < fewest) e.putInt("fewest_moves", moves);
        e.apply();
    }
    public void gameAbandoned() {
        if (currentStreak() != 0) prefs.edit().putInt("current_streak", 0).apply();
    }

    public int gamesStarted() { return prefs.getInt("games_started", 0); }
    public int gamesWon() { return prefs.getInt("games_won", 0); }
    public int currentStreak() { return prefs.getInt("current_streak", 0); }
    public int bestStreak() { return prefs.getInt("best_streak", 0); }
    public long fastestWin() { return prefs.getLong("fastest_win", 0); }
    public int fewestMoves() { return prefs.getInt("fewest_moves", 0); }
    public int winPercent() { return gamesStarted() == 0 ? 0 : Math.round(gamesWon() * 100f / gamesStarted()); }
}
