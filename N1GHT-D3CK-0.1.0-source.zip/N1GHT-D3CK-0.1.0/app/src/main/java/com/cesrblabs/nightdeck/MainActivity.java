package com.cesrblabs.nightdeck;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

public final class MainActivity extends Activity {
    private NightDeckView gameView;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(0xFF09070D);
        window.setNavigationBarColor(0xFF09070D);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        gameView = new NightDeckView(this);
        setContentView(gameView);
    }
    @Override protected void onPause() {
        if (gameView != null) gameView.persist();
        super.onPause();
    }
}
